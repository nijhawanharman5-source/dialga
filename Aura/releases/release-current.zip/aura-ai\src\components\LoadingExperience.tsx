import { motion, Variants } from 'framer-motion'
import { Brain, Zap, Search, Code, BrainCog, Sparkles, Layout, BrainCircuit, Settings, List, Bot, Monitor, Activity, TrendingUp } from 'lucide-react'
import { useAuraStore } from '@/store'
import React from 'react'

const thinkingVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  exit: { opacity: 0, y: -20, transition: { duration: 0.3 } }
}

const pulseVariants: Variants = {
  hidden: { scale: 0.95, opacity: 0.7 },
  visible: { scale: 1, opacity: 1, transition: { duration: 1.5, repeat: Infinity, type: "spring" } }
}

const gradientVariants: Variants = {
  hidden: { backgroundPosition: '0% 50%' },
  visible: { backgroundPosition: '100% 50%', transition: { duration: 8, repeat: Infinity, ease: "linear" } }
}

const thinkingMessages = {
  coding: [
    "Analyzing code structure...",
    "Finding optimal solution...",
    "Checking for edge cases...",
    "Optimizing performance...",
    "Reviewing syntax and best practices..."
  ],
  writing: [
    "Generating ideas...",
    "Structuring content...",
    "Finding the right tone...",
    "Polishing language...",
    "Ensuring clarity and flow..."
  ],
  research: [
    "Gathering sources...",
    "Analyzing information...",
    "Cross-referencing data...",
    "Synthesizing findings...",
    "Drawing conclusions..."
  ],
  planning: [
    "Breaking down the problem...",
    "Identifying dependencies...",
    "Creating action steps...",
    "Setting priorities...",
    "Building a roadmap..."
  ],
  vision: [
    "Analyzing visual elements...",
    "Identifying objects and patterns...",
    "Understanding context...",
    "Extracting key information...",
    "Generating descriptive analysis..."
  ],
  default: [
    "Understanding your request...",
    "Selecting the best intelligence...",
    "Searching internal memory...",
    "Planning response...",
    "Cross-checking information...",
    "Finalizing answer..."
  ]
}

interface LoadingExperienceProps {
  taskType?: string
  forceHide?: boolean
}

export function LoadingExperience({ taskType, forceHide }: LoadingExperienceProps) {
  const { isStreaming } = useAuraStore()

  if (forceHide || !isStreaming) return null

  const messages = thinkingMessages[taskType as keyof typeof thinkingMessages] || thinkingMessages.default
  const [currentIndex, setCurrentIndex] = React.useState(0)

  // Change message every 3 seconds
  React.useEffect(() => {
    if (!isStreaming) return

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % messages.length)
    }, 3000)

    return () => clearInterval(interval)
  }, [isStreaming, messages.length])

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      exit="exit"
      className="fixed inset-0 z-50 pointer-events-none"
    >
      <div className="fixed inset-0 pointer-events-none backdrop-blur-sm bg-black/50">
        <div className="absolute inset-0 pointer-events-none" style={gradientVariants.visible as any} />
      </div>

      <div className="fixed inset-0 flex items-center justify-center pointer-events-none z-50">
        <div className="space-y-6 text-center max-w-xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/10 backdrop-blur-sm shadow-lg">
            <motion.div
              className="h-8 w-8 bg-gradient-to-br from-aura-300 via-fuchsia-300 to-pink-300 rounded-full"
              variants={pulseVariants}
              initial="hidden"
              animate="visible"
            />
          </div>

          <motion.p
            variants={thinkingVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="text-xl font-semibold text-white/90"
          >
            {messages[currentIndex]}
          </motion.p>

          <div className="flex h-4 w-24 items-center justify-between space-x-2">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                variants={{
                  hidden: { opacity: 0.2, scale: 0.8 },
                  visible: {
                    opacity: [0.2, 0.6, 1],
                    scale: [0.8, 1, 1.2],
                    transition: {
                      duration: 0.6,
                      delay: i * 0.2,
                      repeat: Infinity,
                      type: "spring"
                    }
                  }
                }}
                initial="hidden"
                animate="visible"
                className="h-2 w-2 rounded-full bg-white/40"
              />
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  )
}