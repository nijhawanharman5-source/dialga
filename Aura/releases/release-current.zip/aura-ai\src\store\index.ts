import { create } from 'zustand'
import type {
  Conversation, Message, ViewMode, UserPreferences, Memory,
  AIConfig, AIMode, AIProvider,
  APIProfile, SmartRouting, SavedModel, ModelPreset,
  AuraVirtualModel, ModelSelection,
  DevLogEntry, DevDashboardStats,
  VoiceSettings, PluginManifest,
  PipelineStep, TaskType,
} from '@/types'
import {
  loadDefaultSelection,
  loadVirtualModels,
  saveDefaultSelection,
  saveVirtualModels,
} from '@/services/auraModels'

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 9)
}

interface AuraState {
  // ─── Conversations ────────────────────────────────────────────────────────
  conversations: Conversation[]
  activeConversationId: string | null
  viewMode: ViewMode
  sidebarOpen: boolean
  commandPaletteOpen: boolean
  isStreaming: boolean
  activePipeline: PipelineStep[] | null

  // ─── Memory ────────────────────────────────────────────────────────────────
  memories: Memory[]
  memoryEnabled: boolean

  // ─── Preferences ───────────────────────────────────────────────────────────
  preferences: UserPreferences

  // ─── AI Config (legacy) ────────────────────────────────────────────────────
  aiConfig: AIConfig | null
  aiMode: AIMode

  // ─── API Profiles ──────────────────────────────────────────────────────────
  profiles: APIProfile[]
  activeProfileId: string | null
  presets: ModelPreset[]

  // ─── Smart Routing ──────────────────────────────────────────────────────────
  routing: SmartRouting

  // ─── Models ──────────────────────────────────────────────────────────────────
  savedModels: SavedModel[]

  // ─── Aura virtual models ─────────────────────────────────────────────────────
  virtualModels: AuraVirtualModel[]
  defaultModelSelection: ModelSelection

  // ─── Developer Dashboard ─────────────────────────────────────────────────────
  devLogs: DevLogEntry[]
  devStats: DevDashboardStats | null

  // ─── Voice ────────────────────────────────────────────────────────────────────
  voiceSettings: VoiceSettings | null
  voiceListening: boolean
  voiceSpeaking: boolean
  availableVoices: { uri: string; name: string; lang: string }[]

  // ─── Plugins ──────────────────────────────────────────────────────────────────
  plugins: PluginManifest[]

  // ─── Actions ───────────────────────────────────────────────────────────────────
  activeConversation: () => Conversation | null
  createConversation: () => string
  deleteConversation: (id: string) => void
  setActiveConversation: (id: string) => void
  addMessage: (conversationId: string, message: Message) => void
  updateMessage: (conversationId: string, messageId: string, updates: Partial<Message>) => void
  setViewMode: (mode: ViewMode) => void
  toggleSidebar: () => void
  toggleCommandPalette: () => void
  setStreaming: (streaming: boolean) => void
  setActivePipeline: (steps: PipelineStep[] | null) => void
  addMemory: (memory: Memory) => void
  setMemories: (memories: Memory[]) => void
  updatePreferences: (prefs: Partial<UserPreferences>) => void
  setAIConfig: (config: AIConfig) => void
  setAIMode: (mode: AIMode) => void
  setProfiles: (profiles: APIProfile[]) => void
  setActiveProfileId: (id: string | null) => void
  setPresets: (presets: ModelPreset[]) => void
  setRouting: (routing: SmartRouting) => void
  setSavedModels: (models: SavedModel[]) => void
  setVirtualModels: (models: AuraVirtualModel[]) => void
  setDefaultModelSelection: (selection: ModelSelection) => void
  setConversationModelSelection: (conversationId: string, selection: ModelSelection) => void
  setDevLogs: (logs: DevLogEntry[]) => void
  setDevStats: (stats: DevDashboardStats | null) => void
  setVoiceSettings: (settings: VoiceSettings) => void
  setVoiceListening: (listening: boolean) => void
  setVoiceSpeaking: (speaking: boolean) => void
  setAvailableVoices: (voices: { uri: string; name: string; lang: string }[]) => void
  setPlugins: (plugins: PluginManifest[]) => void
}

export const useAuraStore = create<AuraState>((set, get) => ({
  conversations: [],
  activeConversationId: null,
  viewMode: 'chat',
  sidebarOpen: true,
  commandPaletteOpen: false,
  isStreaming: false,
  activePipeline: null,

  memories: [],
  memoryEnabled: true,

  preferences: {
    theme: 'dark',
    accentColor: '#3b82f6', // blue-500 as default
    fontSize: 14,
    messageSpacing: 'normal',
    codeTheme: 'default',
    developerMode: false,
    showModelInMessages: true,
    showTimestamps: true,
    soundEffects: true,
    notifications: true,
    autoSave: true,
    sendOnEnter: true,
    spellCheck: true,
    language: 'en',
    responseLength: 'balanced',
    showPipeline: true,
    enableMemory: true,
  },

  aiConfig: null,
  aiMode: 'think',

  profiles: [],
  activeProfileId: null,
  presets: [],

  routing: {
    chat: null,
    coding: null,
    planning: null,
    vision: null,
    voice: null,
    embeddings: null,
  },

  savedModels: [],
  virtualModels: loadVirtualModels(),
  defaultModelSelection: loadDefaultSelection(),
  devLogs: [],
  devStats: null,
  voiceSettings: null,
  voiceListening: false,
  voiceSpeaking: false,
  availableVoices: [],
  plugins: [],

  // ─── Conversation actions ─────────────────────────────────────────────────
  activeConversation: () => {
    const state = get()
    return state.conversations.find(c => c.id === state.activeConversationId) ?? null
  },

  createConversation: () => {
    const id = generateId()
    const conversation: Conversation = {
      id,
      title: 'New conversation',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }
    set(state => ({
      conversations: [conversation, ...state.conversations],
      activeConversationId: id,
      viewMode: 'chat',
    }))
    return id
  },

  deleteConversation: (id) => {
    set(state => {
      const filtered = state.conversations.filter(c => c.id !== id)
      return {
        conversations: filtered,
        activeConversationId: state.activeConversationId === id
          ? (filtered[0]?.id ?? null)
          : state.activeConversationId,
      }
    })
  },

  setActiveConversation: (id) => {
    set({ activeConversationId: id, viewMode: 'chat' })
  },

  addMessage: (conversationId, message) => {
    set(state => ({
      conversations: state.conversations.map(c =>
        c.id === conversationId
          ? {
              ...c,
              messages: [...c.messages, message],
              updatedAt: Date.now(),
              title: c.messages.length === 0 && message.role === 'user'
                ? message.content.slice(0, 60) + (message.content.length > 60 ? '…' : '')
                : c.title,
            }
          : c
      ),
    }))
  },

  updateMessage: (conversationId, messageId, updates) => {
    set(state => ({
      conversations: state.conversations.map(c =>
        c.id === conversationId
          ? {
              ...c,
              messages: c.messages.map(m =>
                m.id === messageId ? { ...m, ...updates } : m
              ),
              updatedAt: Date.now(),
            }
          : c
      ),
    }))
  },

  // ─── UI actions ───────────────────────────────────────────────────────────
  setViewMode: (mode) => set({ viewMode: mode }),
  toggleSidebar: () => set(state => ({ sidebarOpen: !state.sidebarOpen })),
  toggleCommandPalette: () => set(state => ({ commandPaletteOpen: !state.commandPaletteOpen })),
  setStreaming: (streaming) => set({ isStreaming: streaming }),
  setActivePipeline: (steps) => set({ activePipeline: steps }),

  // ─── Memory actions ────────────────────────────────────────────────────────
  addMemory: (memory) => set(state => ({ memories: [...state.memories, memory] })),
  setMemories: (memories) => set({ memories }),
  updatePreferences: (prefs) => set(state => ({
    preferences: { ...state.preferences, ...prefs },
  })),

  // ─── AI config actions ────────────────────────────────────────────────────
  setAIConfig: (config) => set({ aiConfig: config, aiMode: config.aiMode }),
  setAIMode: (mode) => set({ aiMode: mode }),

  // ─── Profile actions ───────────────────────────────────────────────────────
  setProfiles: (profiles) => {
    const active = profiles.find(p => p.isDefault)?.id ?? profiles[0]?.id ?? null
    set({ profiles, activeProfileId: active })
  },
  setActiveProfileId: (id) => set({ activeProfileId: id }),
  setPresets: (presets) => set({ presets }),

  // ─── Routing actions ────────────────────────────────────────────────────────
  setRouting: (routing) => set({ routing }),

  // ─── Model actions ──────────────────────────────────────────────────────────
  setSavedModels: (models) => set({ savedModels: models }),
  setVirtualModels: (models) => {
    saveVirtualModels(models)
    set({ virtualModels: models })
  },
  setDefaultModelSelection: (selection) => {
    saveDefaultSelection(selection)
    set({ defaultModelSelection: selection })
  },
  setConversationModelSelection: (conversationId, selection) => {
    set(state => ({
      conversations: state.conversations.map(c =>
        c.id === conversationId ? { ...c, modelSelection: selection } : c
      ),
    }))
  },

  // ─── Dev dashboard actions ──────────────────────────────────────────────────
  setDevLogs: (logs) => set({ devLogs: logs }),
  setDevStats: (stats) => set({ devStats: stats }),

  // ─── Voice actions ───────────────────────────────────────────────────────────
  setVoiceSettings: (settings) => set({ voiceSettings: settings }),
  setVoiceListening: (listening) => set({ voiceListening: listening }),
  setVoiceSpeaking: (speaking) => set({ voiceSpeaking: speaking }),
  setAvailableVoices: (voices) => set({ availableVoices: voices }),

  // ─── Plugin actions ──────────────────────────────────────────────────────────
  setPlugins: (plugins) => set({ plugins }),
}))
