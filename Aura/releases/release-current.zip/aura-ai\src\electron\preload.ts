import { contextBridge, ipcRenderer } from 'electron'

type BridgeMessage = {
  role: 'user' | 'assistant' | 'system'
  content: string
}

type BridgeMemoryInput = {
  type?: 'short_term' | 'long_term' | 'preference' | 'project' | 'coding' | 'learning' | 'goal'
  content: string
  context?: string
  relevance?: number
  expiresAt?: number | null
}

type ChatEventName = 'delta' | 'thinking' | 'done' | 'error' | 'aborted' | 'pipeline'
type ChatEventPayload = Record<string, unknown>
type ChatStartOptions = { memoryEnabled?: boolean; profileId?: string }

contextBridge.exposeInMainWorld('aura', {
  window: {
    minimize: () => ipcRenderer.invoke('window-minimize'),
    maximize: () => ipcRenderer.invoke('window-maximize'),
    close: () => ipcRenderer.invoke('window-close'),
    isMaximized: () => ipcRenderer.invoke('window-is-maximized'),
  },
  ai: {
    getStatus: () => ipcRenderer.invoke('ai:get-status'),
    getConfig: () => ipcRenderer.invoke('ai:get-config'),
    setConfig: (partial: Record<string, unknown>) => ipcRenderer.invoke('ai:set-config', partial),
    testConnection: (config: Record<string, unknown>) => ipcRenderer.invoke('ai:test-connection', config),
    getPresets: () => ipcRenderer.invoke('ai:get-presets'),
    exportConfig: () => ipcRenderer.invoke('ai:export-config'),
    importConfig: (json: string) => ipcRenderer.invoke('ai:import-config', json),
  },
  profiles: {
    list: () => ipcRenderer.invoke('profiles:list'),
    create: (profile: Record<string, unknown>) => ipcRenderer.invoke('profiles:create', profile),
    update: (id: string, updates: Record<string, unknown>) => ipcRenderer.invoke('profiles:update', id, updates),
    delete: (id: string) => ipcRenderer.invoke('profiles:delete', id),
    duplicate: (id: string) => ipcRenderer.invoke('profiles:duplicate', id),
    setDefault: (id: string) => ipcRenderer.invoke('profiles:set-default', id),
    enable: (id: string, enabled: boolean) => ipcRenderer.invoke('profiles:enable', id, enabled),
    getActive: () => ipcRenderer.invoke('profiles:get-active'),
    setActive: (id: string) => ipcRenderer.invoke('profiles:set-active', id),
    testConnection: (profile: Record<string, unknown>) => ipcRenderer.invoke('profiles:test-connection', profile),
    exportAll: () => ipcRenderer.invoke('profiles:export-all'),
    importAll: (json: string) => ipcRenderer.invoke('profiles:import-all', json),
    backup: () => ipcRenderer.invoke('profiles:backup'),
    restore: (json: string) => ipcRenderer.invoke('profiles:restore', json),
  },
  routing: {
    get: () => ipcRenderer.invoke('routing:get'),
    set: (routing: Record<string, unknown>) => ipcRenderer.invoke('routing:set', routing),
    resolve: (task: string) => ipcRenderer.invoke('routing:resolve', task),
    detectTask: (content: string) => ipcRenderer.invoke('routing:detect-task', content),
    autoSelect: (content: string) => ipcRenderer.invoke('routing:auto-select', content),
  },
  models: {
    list: () => ipcRenderer.invoke('models:list'),
    add: (model: Record<string, unknown>) => ipcRenderer.invoke('models:add', model),
    update: (id: string, updates: Record<string, unknown>) => ipcRenderer.invoke('models:update', id, updates),
    delete: (id: string) => ipcRenderer.invoke('models:delete', id),
    togglePin: (id: string) => ipcRenderer.invoke('models:toggle-pin', id),
    toggleFavorite: (id: string) => ipcRenderer.invoke('models:toggle-favorite', id),
    exportAll: () => ipcRenderer.invoke('models:export-all'),
    importAll: (json: string) => ipcRenderer.invoke('models:import-all', json),
  },
  devlogs: {
    list: () => ipcRenderer.invoke('devlogs:list'),
    clear: () => ipcRenderer.invoke('devlogs:clear'),
    stats: () => ipcRenderer.invoke('devlogs:stats'),
  },
  voice: {
    getSettings: () => ipcRenderer.invoke('voice:get-settings'),
    setSettings: (settings: Record<string, unknown>) => ipcRenderer.invoke('voice:set-settings', settings),
    getVoices: () => ipcRenderer.invoke('voice:get-voices'),
  },
  plugins: {
    list: () => ipcRenderer.invoke('plugins:list'),
    enable: (id: string) => ipcRenderer.invoke('plugins:enable', id),
    disable: (id: string) => ipcRenderer.invoke('plugins:disable', id),
    remove: (id: string) => ipcRenderer.invoke('plugins:remove', id),
    install: (manifest: Record<string, unknown>) => ipcRenderer.invoke('plugins:install', manifest),
  },
  security: {
    maskKey: (key: string) => ipcRenderer.invoke('security:mask-key', key),
    secureCopy: (text: string) => ipcRenderer.invoke('security:secure-copy', text),
  },
  chat: {
    start: (streamId: string, messages: BridgeMessage[], options?: ChatStartOptions) =>
      ipcRenderer.invoke('chat:start', {
        streamId,
        messages: messages.map(message => ({
          role: message.role,
          content: message.content,
        })),
        ...(options ? { options: { memoryEnabled: options.memoryEnabled, profileId: options.profileId } } : {}),
      }),
    abort: (streamId: string) => ipcRenderer.invoke('chat:abort', streamId),
    on: (eventName: ChatEventName, callback: (payload: ChatEventPayload) => void) => {
      const channel = `chat:${eventName}`
      const listener = (_event: Electron.IpcRendererEvent, payload: ChatEventPayload) => callback(payload)
      ipcRenderer.on(channel, listener)
      return () => ipcRenderer.removeListener(channel, listener)
    },
  },
  memory: {
    list: () => ipcRenderer.invoke('memory:list'),
    create: (input: BridgeMemoryInput) => ipcRenderer.invoke('memory:create', input),
    delete: (id: string) => ipcRenderer.invoke('memory:delete', id),
    update: (id: string, content: string) => ipcRenderer.invoke('memory:update', id, content),
    export: () => ipcRenderer.invoke('memory:export'),
    import: (json: string) => ipcRenderer.invoke('memory:import', json),
  },
  onToggleCommandPalette: (callback: () => void) => {
    ipcRenderer.on('toggle-command-palette', callback)
    return () => ipcRenderer.removeListener('toggle-command-palette', callback)
  },
  getTheme: () => ipcRenderer.invoke('get-theme'),
})
