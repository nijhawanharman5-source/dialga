import { ArrowUp, Mic, MicOff, Paperclip, Square, Zap, Scale, Brain, ListChecks, Rocket, Flame } from 'lucide-react'
import { FormEvent, KeyboardEvent, useRef, useState } from 'react'
import { cn } from '@/utils/cn'
import { useAuraStore } from '@/store'
import type { AIMode } from '@/types'
import { Attachment } from '@/types'

const MODES: { mode: AIMode | 'auto'; icon: React.ElementType; label: string; color: string }[] = [
  { mode: 'auto', icon: Zap, label: 'Auto', color: 'text-aura-400' },
  { mode: 'fast', icon: Zap, label: 'Fast', color: 'text-yellow-400' },
  { mode: 'balanced', icon: Scale, label: 'Balanced', color: 'text-emerald-400' },
  { mode: 'think', icon: Brain, label: 'Think', color: 'text-blue-400' },
  { mode: 'plan', icon: ListChecks, label: 'Plan', color: 'text-teal-400' },
  { mode: 'max', icon: Rocket, label: 'Max', color: 'text-purple-400' },
  { mode: 'bypass', icon: Flame, label: 'Bypass', color: 'text-red-400' },
]

export function ChatComposer({ disabled, isStreaming, onAbort, onSend }: {
  disabled?: boolean
  isStreaming: boolean
  onAbort: () => void
  onSend: (message: string | { text: string; attachments: Attachment[] }) => void
}) {
  const [value, setValue] = useState('')
  const textareaRef = useRef<HTMLTextAreaElement | null>(null)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const { aiMode, setAIMode, voiceListening, setVoiceListening } = useAuraStore()

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onload = () => {
        if (reader.result) {
          resolve(reader.result as string)
        } else {
          reject(new Error('Failed to read file'))
        }
      }
      reader.onerror = (error) => {
        reject(error)
      }
    })
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    setSelectedFiles(files)
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index))
  }

    function submit(event?: FormEvent) {
    event?.preventDefault()
    const trimmed = value.trim()
    if (!trimmed && selectedFiles.length === 0) return
    if (selectedFiles.length > 0) {
      Promise.all(selectedFiles.map(file => fileToBase64(file)))
        .then(dataArray => {
          const attachments: Attachment[] = selectedFiles.map((file, index) => ({
            id: `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}_${index}`,
            name: file.name,
            type: file.type,
            size: file.size,
            data: dataArray[index],
            // We don't have a URL or thumbnail for now, but we can generate a thumbnail for images later if needed.
            thumbnail: undefined,
          }))
          onSend({ text: trimmed, attachments })
          setSelectedFiles([])
          if (textareaRef.current) {
            textareaRef.current.value = ''
          }
          if (fileInputRef.current) {
            fileInputRef.current.value = ''
          }
          setValue('')
          requestAnimationFrame(() => {
            if (textareaRef.current) {
              textareaRef.current.style.height = '48px'
            }
          })
        })
        .catch(error => {
          console.error('Error processing files:', error)
          // Fallback to sending just the text if file processing fails
          onSend(trimmed)
          setSelectedFiles([])
          if (textareaRef.current) {
            textareaRef.current.value = ''
          }
          if (fileInputRef.current) {
            fileInputRef.current.value = ''
          }
          setValue('')
          requestAnimationFrame(() => {
            if (textareaRef.current) {
              textareaRef.current.style.height = '48px'
            }
          })
        })
    } else {
      onSend(trimmed)
      setValue('')
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.style.height = '48px'
        }
      })
    }
  }

  function onKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      submit()
    }
  }

  function switchMode(mode: AIMode | 'auto') {
    const modeToSet: AIMode = mode === 'auto' ? 'think' : mode
    setAIMode(modeToSet)
    window.aura?.ai.setConfig({ aiMode: modeToSet }).catch(() => {})
  }

  function toggleVoice() {
    setVoiceListening(!voiceListening)
    // Voice STT/TTS is handled in the VoicePanel component via Web Speech API
  }

  return (
    <form className="mx-auto w-full max-w-4xl px-4 pb-5" onSubmit={submit}>
      <div className="rounded-3xl border border-white/12 bg-surface-1/90 p-2 shadow-2xl shadow-black/40 backdrop-blur-3xl">
        <div className="flex items-start">
          <textarea
            className="max-h-44 min-h-12 w-full resize-none bg-transparent px-4 py-3 text-[15px] leading-7 text-white outline-none placeholder:text-white/28"
            disabled={disabled}
            onChange={event => {
              setValue(event.target.value)
              event.target.style.height = '48px'
              event.target.style.height = `${Math.min(event.target.scrollHeight, 176)}px`
            }}
            onKeyDown={onKeyDown}
            placeholder="Ask Aura anything — code, research, plan, create, debug…"
            ref={textareaRef}
            rows={1}
            value={value}
          />
          {selectedFiles.length > 0 && (
            <div className="ml-2 flex flex-col items-start space-y-1">
              {selectedFiles.map((file, index) => (
                <div key={index} className="flex items-center gap-1 text-xs">
                  <span className="flex items-center justify-center w-3 h-3 bg-gray-500 text-white rounded">📎</span>
                  <span className="truncate w-20">{file.name}</span>
                  <button
                    onClick={() => removeFile(index)}
                    className="text-red-500 hover:text-red-700"
                    title="Remove file"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="flex items-end w-full pt-1">
          {/* Mode selector strip */}
          <div className="flex items-center gap-1 px-3 pb-1.5 pt-0.5">
            {MODES.map(({ mode, icon: Icon, label, color }) => {
              const active = aiMode === mode || (!aiMode && mode === 'think')
              return (
                <button
                  key={mode}
                  className={cn(
                    'flex items-center gap-1 rounded-xl px-2.5 py-1 text-[11px] font-medium transition',
                    active
                      ? cn('bg-white/10', color)
                      : 'text-white/30 hover:bg-white/6 hover:text-white/60'
                  )}
                  onClick={() => switchMode(mode)}
                  title={label}
                  type="button"
                >
                  <Icon size={11} />
                  <span className="hidden sm:inline">{label}</span>
                </button>
              )
            })}
          </div>
          <div className="flex items-center justify-between w-full px-2 pb-1">
            <div className="flex items-center gap-1">
              <button
                className={cn(
                  'rounded-xl p-2 text-white/35 transition hover:bg-white/8 hover:text-white/75'
                )}
                onClick={triggerFileInput}
                title="Attach files"
                type="button"
              >
                <Paperclip size={18} />
              </button>
              {selectedFiles.length > 0 && (
                <span className="ml-2 text-xs text-white/50">{selectedFiles.length} file{selectedFiles.length > 1 ? 's' : ''}</span>
              )}
              <button
                className={cn(
                  'rounded-xl p-2 transition',
                  voiceListening
                    ? 'bg-red-500/20 text-red-400'
                    : 'text-white/35 hover:bg-white/8 hover:text-white/75'
                )}
                onClick={toggleVoice}
                title={voiceListening ? 'Stop voice input' : 'Voice input'}
                type="button"
              >
                {voiceListening ? <MicOff size={18} /> : <Mic size={18} />}
              </button>
              <div className="ml-2 hidden text-xs text-white/28 sm:block">Enter to send · Shift Enter for newline</div>
            </div>
            {isStreaming ? (
              <button
                className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/12 text-white transition hover:bg-white/18"
                onClick={onAbort}
                type="button"
              >
                <Square size={15} fill="currentColor" />
              </button>
            ) : (
              <button
                className={cn(
                  'flex h-10 w-10 items-center justify-center rounded-2xl transition',
                  (value.trim() || selectedFiles.length > 0) && !disabled
                    ? 'bg-white text-surface-0 hover:scale-105'
                    : 'bg-white/8 text-white/28'
                )}
                disabled={!(value.trim() || selectedFiles.length > 0) || disabled}
                type="submit"
              >
                <ArrowUp size={18} />
              </button>
            )}
          </div>
        </div>
      </div>
    </form>
  )
}