import { Check, Loader2, Settings, X } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import * as Tabs from '@radix-ui/react-tabs'
import { useAuraStore } from '@/store'
import type { AIConfig, ModelPreset } from '@/types'
import { APIDashboardTab } from './settings/APIDashboardTab'
import { AppearanceTab } from './settings/AppearanceTab'
import { AuraModelsTab } from './settings/AuraModelsTab'
import { ModelManagerTab } from './settings/ModelManagerTab'
import { ModesTab } from './settings/ModesTab'
import { SmartRoutingTab } from './settings/SmartRoutingTab'
import { VoiceSettingsTab } from './settings/VoiceSettingsTab'

function useDebouncedSave(config: AIConfig | null, delay = 600) {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [savedFlash, setSavedFlash] = useState(false)
  const { setAIConfig } = useAuraStore()

  const save = useCallback(
    (partial: Partial<AIConfig>) => {
      if (!config) return
      const updated = { ...config, ...partial }
      if (timerRef.current) clearTimeout(timerRef.current)
      timerRef.current = setTimeout(async () => {
        try {
          const result = await window.aura!.ai.setConfig(partial)
          setAIConfig(result)
          setSavedFlash(true)
          setTimeout(() => setSavedFlash(false), 1800)
        } catch (error) {
          console.error('Save config failed:', error)
        }
      }, delay)
      setAIConfig(updated as AIConfig)
    },
    [config, delay, setAIConfig]
  )

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  return { save, savedFlash }
}

export function SettingsPanel() {
  const {
    aiConfig,
    setAIConfig,
    setAIMode,
    setViewMode,
    setProfiles,
    setSavedModels,
    setRouting,
    setVoiceSettings,
    setDevLogs,
    setDevStats,
    setPlugins,
  } = useAuraStore()
  const [presets, setPresets] = useState<ModelPreset[]>([])

  useEffect(() => {
    if (!window.aura) return

    Promise.all([
      window.aura.ai.getConfig(),
      window.aura.ai.getPresets(),
      window.aura.profiles.list(),
      window.aura.models.list(),
      window.aura.routing.get(),
      window.aura.voice.getSettings(),
      window.aura.devlogs.list(),
      window.aura.devlogs.stats(),
      window.aura.plugins.list(),
    ])
      .then(([config, presetList, profiles, models, routing, voice, devLogs, devStats, plugins]) => {
        setAIConfig(config)
        setPresets(presetList)
        setProfiles(profiles)
        setSavedModels(models)
        setRouting(routing)
        setVoiceSettings(voice)
        setDevLogs(devLogs)
        setDevStats(devStats)
        setPlugins(plugins)
      })
      .catch(console.error)
  }, [setAIConfig, setProfiles, setSavedModels, setRouting, setVoiceSettings, setDevLogs, setDevStats, setPlugins])

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setViewMode('chat')
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [setViewMode])

  const { save, savedFlash } = useDebouncedSave(aiConfig)

  if (!aiConfig) {
    return (
      <section className="flex h-full min-w-0 flex-1 items-center justify-center">
        <Loader2 className="animate-spin text-white/40" size={28} />
      </section>
    )
  }

  return (
    <section className="flex h-full min-w-0 flex-1 flex-col overflow-hidden">
      <header className="shrink-0 border-b border-white/6 px-7 py-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-aura-300">
            <Settings size={18} />
            <span className="text-sm font-medium">Settings</span>
          </div>
          <div className="flex items-center gap-3">
            {savedFlash && (
              <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-medium text-emerald-400">
                <Check size={12} /> Saved
              </span>
            )}
            <button
              className="rounded-xl p-1.5 text-white/40 transition hover:bg-white/8 hover:text-white/80"
              onClick={() => setViewMode('chat')}
              title="Close settings (Esc)"
              type="button"
            >
              <X size={18} />
            </button>
          </div>
        </div>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight text-white">Configuration</h1>
      </header>

      <Tabs.Root className="flex min-h-0 flex-1 flex-col" defaultValue="api-dashboard">
        <Tabs.List className="flex shrink-0 gap-1 border-b border-white/6 px-6 pt-3">
          {[
            { value: 'api-dashboard', label: 'API Dashboard' },
            { value: 'aura-models', label: 'Aura Models' },
            { value: 'modes', label: 'AI Modes' },
            { value: 'models', label: 'Model Manager' },
            { value: 'smart-routing', label: 'Smart Routing' },
            { value: 'voice', label: 'Voice' },
            { value: 'appearance', label: 'Appearance' },
          ].map(tab => (
            <Tabs.Trigger
              key={tab.value}
              className="rounded-t-xl border border-b-0 border-transparent px-4 py-2 text-sm text-white/45 transition data-[state=active]:border-white/10 data-[state=active]:bg-white/[0.055] data-[state=active]:text-white"
              value={tab.value}
            >
              {tab.label}
            </Tabs.Trigger>
          ))}
        </Tabs.List>

        <div className="min-h-0 flex-1 overflow-y-auto">
          <Tabs.Content className="p-6" value="api-dashboard">
            <APIDashboardTab presets={presets} />
          </Tabs.Content>
          <Tabs.Content className="p-6" value="aura-models">
            <AuraModelsTab />
          </Tabs.Content>
          <Tabs.Content className="p-6" value="modes">
            <ModesTab />
          </Tabs.Content>
          <Tabs.Content className="p-6" value="models">
            <ModelManagerTab presets={presets} />
          </Tabs.Content>
          <Tabs.Content className="p-6" value="smart-routing">
            <SmartRoutingTab />
          </Tabs.Content>
          <Tabs.Content className="p-6" value="voice">
            <VoiceSettingsTab />
          </Tabs.Content>
          <Tabs.Content className="p-6" value="appearance">
            <AppearanceTab />
          </Tabs.Content>
        </div>
      </Tabs.Root>
    </section>
  )
}
