import { cn } from '@/utils/cn'
import { useAuraStore } from '@/store'
import { Card, Toggle } from './shared'

export function AppearanceTab() {
  const { preferences, updatePreferences } = useAuraStore()

  return (
    <div className="max-w-xl space-y-5">
      <Card title="Theme">
        <div className="flex gap-2">
          {(['dark', 'light', 'system'] as const).map(t => (
            <button
              key={t}
              className={cn(
                'flex-1 rounded-2xl border py-2.5 text-sm font-medium capitalize transition',
                preferences.theme === t ? 'border-white/25 bg-white/12 text-white' : 'border-white/6 text-white/40 hover:border-white/14 hover:text-white/70'
              )}
              onClick={() => updatePreferences({ theme: t })}
            >
              {t}
            </button>
          ))}
        </div>
      </Card>

      <Card title="Font Size">
        <div className="flex items-center gap-4">
          <input className="flex-1 accent-white/70" type="range" min={11} max={20} value={preferences.fontSize} onChange={e => updatePreferences({ fontSize: Number(e.target.value) })} />
          <span className="w-10 text-right text-sm text-white/60">{preferences.fontSize}px</span>
        </div>
      </Card>

      <Card title="Response Length">
        <div className="flex gap-2">
          {(['concise', 'balanced', 'detailed'] as const).map(r => (
            <button
              key={r}
              className={cn(
                'flex-1 rounded-2xl border py-2.5 text-sm font-medium capitalize transition',
                preferences.responseLength === r ? 'border-white/25 bg-white/12 text-white' : 'border-white/6 text-white/40 hover:border-white/14 hover:text-white/70'
              )}
              onClick={() => updatePreferences({ responseLength: r })}
            >
              {r}
            </button>
          ))}
        </div>
      </Card>

      <Card title="Pipeline & Memory">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm text-white/60">Show reasoning pipeline</span>
              <p className="text-xs text-white/30">Display the reasoning steps before responses</p>
            </div>
            <Toggle checked={preferences.showPipeline ?? false} onChange={v => updatePreferences({ showPipeline: v })} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm text-white/60">Enable memory</span>
              <p className="text-xs text-white/30">Remember context across conversations</p>
            </div>
            <Toggle checked={preferences.enableMemory ?? true} onChange={v => updatePreferences({ enableMemory: v })} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm text-white/60">Auto-save</span>
              <p className="text-xs text-white/30">Automatically save settings changes</p>
            </div>
            <Toggle checked={preferences.autoSave ?? true} onChange={v => updatePreferences({ autoSave: v })} />
          </div>
        </div>
      </Card>
    </div>
  )
}
