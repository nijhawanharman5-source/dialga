import { useAuraStore } from '@/store'
import { useEffect, useState } from 'react'
import { Zap, Scale, Brain, ListChecks, Rocket, Flame } from 'lucide-react'
import { cn } from '@/utils/cn'
import type { AIMode } from '@/types'

const MODE_INFO: Record<'auto' | 'fast' | 'balanced' | 'think' | 'plan' | 'max' | 'bypass', {
  label: string
  icon: React.ElementType
  color: string
  description: string
  quality: string
  speed: string
}> = {
  auto: {
    label: 'Auto',
    icon: Zap,
    color: 'text-aura-400',
    description: 'Automatically selected based on your request',
    quality: 'Adaptive',
    speed: 'Variable'
  },
  fast: {
    label: 'Fast',
    icon: Zap,
    color: 'text-yellow-400',
    description: 'Quick responses for simple queries',
    quality: 'Good',
    speed: 'Fastest'
  },
  balanced: {
    label: 'Balanced',
    icon: Scale,
    color: 'text-emerald-400',
    description: 'Balanced speed and quality',
    quality: 'Very Good',
    speed: 'Fast'
  },
  think: {
    label: 'Think',
    icon: Brain,
    color: 'text-blue-400',
    description: 'Deep reasoning for complex problems',
    quality: 'Excellent',
    speed: 'Medium'
  },
  plan: {
    label: 'Plan',
    icon: ListChecks,
    color: 'text-teal-400',
    description: 'Strategic planning and architecture',
    quality: 'Excellent',
    speed: 'Medium'
  },
  max: {
    label: 'Max',
    icon: Rocket,
    color: 'text-purple-400',
    description: 'Maximum quality and depth',
    quality: 'Outstanding',
    speed: 'Slower'
  },
  bypass: {
    label: 'Bypass',
    icon: Flame,
    color: 'text-red-400',
    description: 'Unrestricted processing power',
    quality: 'Maximum',
    speed: 'Variable'
  }
}

const MODES = ['auto', 'fast', 'balanced', 'think', 'plan', 'max', 'bypass'] as const

interface IntelligenceModeBarProps {
  showDetails?: boolean
}

export function IntelligenceModeBar({ showDetails = true }: IntelligenceModeBarProps = {}) {
  const { aiMode, setAIMode } = useAuraStore()
  const [hoveredMode, setHoveredMode] = useState<'auto' | 'fast' | 'balanced' | 'think' | 'plan' | 'max' | 'bypass' | null>(null)
  const [isAutoMode, setIsAutoMode] = useState(true)

  // Determine if we're in auto mode (when it's not explicitly set)
  useEffect(() => {
    // We consider the default mode 'think' as auto mode for display purposes
    setIsAutoMode(aiMode === 'think')
  }, [aiMode])

  const getModeInfo = (mode: 'auto' | 'fast' | 'balanced' | 'think' | 'plan' | 'max' | 'bypass') => {
    // For display purposes, treat 'think' as auto when it's the default
    const displayMode = mode === 'think' && isAutoMode ? 'auto' : mode
    return MODE_INFO[displayMode as typeof displayMode]
  }

  const handleModeClick = (mode: 'auto' | 'fast' | 'balanced' | 'think' | 'plan' | 'max' | 'bypass') => {
    // When 'auto' is clicked, we set the mode to 'think' (our default) to enable automatic selection
    const modeToSet: AIMode = mode === 'auto' ? 'think' : mode
    setAIMode(modeToSet)
    // Update the backend
    // Note: In a real implementation, you'd call the backend API here
    window.aura?.ai.setConfig({ aiMode: modeToSet }).catch(() => {})
  }

  return (
    <div className="flex flex-wrap items-center gap-2 px-4 py-2 bg-surface-1/90 backdrop-blur-sm rounded-xl border border-white/10">
      {MODES.map((mode) => {
        const info = getModeInfo(mode)
        const isActive = (mode === 'auto' && isAutoMode) || (!isAutoMode && mode === aiMode)
        const isHovered = hoveredMode === mode

        return (
          <div
            key={mode}
            onClick={() => handleModeClick(mode)}
            onMouseEnter={() => setHoveredMode(mode)}
            onMouseLeave={() => setHoveredMode(null)}
            className={cn(
              'flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-lg transition-all duration-200',
              isActive ? 'bg-white/10' : 'hover:bg-white/5',
              isActive ? info.color : 'text-white/40 hover:text-white/60',
              !isActive && isHovered && 'bg-white/5'
            )}
            title={`${info.description} - Quality: ${info.quality}, Speed: ${info.speed}`}
          >
            <info.icon className={`${info.color} ${info.color}/80 h-4 w-4`} />
            <span className="hidden md:inline">{info.label}</span>
            {showDetails && !isActive && !isHovered && (
              <span className="hidden ml-2 text-xs text-white/20">·</span>
            )}
            {showDetails && isHovered && (
              <div className="absolute left-0 top-full mt-2 w-56 p-3 bg-surface-0/80 backdrop-blur-md border border-white/10 rounded-lg shadow-lg text-sm z-50">
                <div className="flex items-start gap-2">
                  <info.icon className={`${info.color} h-5 w-5`} />
                  <div>
                    <p className="font-medium text-white">{info.label} Mode</p>
                    <p className="text-white/70">{info.description}</p>
                    <div className="mt-1 flex gap-3 text-xs text-white/60">
                      <span>Quality: {info.quality}</span>
                      <span>Speed: {info.speed}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )
      })}

      {/* Auto mode indicator */}
      {isAutoMode && showDetails && (
        <div className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium bg-white/10 rounded-lg ml-4">
          <span className="text-aura-400">●</span>
          <span className="text-white/60">Auto Mode Active</span>
        </div>
      )}
    </div>
  )
}