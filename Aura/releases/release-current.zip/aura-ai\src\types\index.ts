export type AIProvider =
  | 'anthropic'
  | 'openai'
  | 'moonshot'
  | 'zai'
  | 'groq'
  | 'openrouter'
  | 'nvidia'
  | 'gemini'
  | 'ollama'
  | 'lmstudio'
  | 'localai'
  | 'vllm'
  | 'deepseek'
  | 'custom'

export type AIMode = 'fast' | 'balanced' | 'think' | 'plan' | 'max' | 'bypass'

export type TaskType = 'chat' | 'coding' | 'planning' | 'vision' | 'voice' | 'embeddings'

export interface SmartRouting {
  chat?: string | null
  coding?: string | null
  planning?: string | null
  vision?: string | null
  voice?: string | null
  embeddings?: string | null
}

// ═══════════════════════════════════════════════════════════════════════════════
// AURA VIRTUAL MODELS - Complete Brand Abstraction
// ═══════════════════════════════════════════════════════════════════════════════

export type AuraCapability =
  | 'coding'
  | 'reasoning'
  | 'research'
  | 'writing'
  | 'vision'
  | 'speed'
  | 'context'
  | 'reliability'
  | 'tools'

export type AuraModelCategory = 
  | 'speed' 
  | 'general' 
  | 'reasoning' 
  | 'expert' 
  | 'creative' 
  | 'vision' 
  | 'smart' 
  | 'experimental' 
  | 'enterprise'
  | 'specialized'

export type CostTier = 'free' | 'low' | 'medium' | 'high' | 'premium' | 'dynamic' | 'variable'

export interface AuraModelMatcher {
  profileId?: string
  provider?: AIProvider
  modelPattern?: string
}

export interface AuraVirtualModel {
  id: string
  name: string
  tagline: string
  description?: string
  capabilities: AuraCapability[]
  chain: AuraModelMatcher[]
  autoFallback: boolean
  builtIn: boolean
  icon?: string
  color?: string
  category?: AuraModelCategory
  contextWindow?: number
  costTier?: CostTier
  systemPrompt?: string
  temperature?: number
  customSettings?: Record<string, any>
}

export interface ModelSelection {
  kind: 'aura' | 'provider'
  id: string
}

// ═══════════════════════════════════════════════════════════════════════════════
// API PROFILES & CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════════

export interface APIProfile {
  id: string
  name: string
  displayName: string
  provider: AIProvider
  apiKey: string
  baseURL: string
  model: string
  organizationId?: string
  projectId?: string
  customHeaders?: Record<string, string>
  queryParameters?: Record<string, string>
  temperature: number
  topP: number
  maxTokens: number
  contextLength: number
  streaming: boolean
  timeout: number
  retryCount: number
  toolCalling: boolean
  visionSupport: boolean
  enabled: boolean
  isDefault: boolean
  category?: string
  createdAt: number
  updatedAt: number
}

export interface SavedModel {
  id: string
  name: string
  provider: AIProvider
  model: string
  description?: string
  pinned?: boolean
  favorite?: boolean
  lastUsed?: number
  usageCount?: number
  category?: string
}

export interface ModelPreset {
  id: string
  name: string
  provider: AIProvider
  model: string
  displayName: string
  capabilities: string[]
  contextWindow: number
  label?: string
  pricing?: {
    input: number
    output: number
  }
}

export interface AIConfig {
  provider: AIProvider
  apiKey: string
  baseURL: string
  model: string
  temperature: number
  maxTokens: number
  streaming: boolean
  aiMode?: AIMode
}

// ═══════════════════════════════════════════════════════════════════════════════
// CONVERSATIONS & MESSAGES
// ═══════════════════════════════════════════════════════════════════════════════

export type MessageRole = 'user' | 'assistant' | 'system'

export interface Message {
  id: string
  role: MessageRole
  content: string
  timestamp: number
  attachments?: Attachment[]
  thinking?: string
  isThinking?: boolean
  isStreaming?: boolean
  modelUsed?: string // Track which Aura model was used
  model?: string // Legacy compatibility
  error?: string
  regenerated?: boolean
  edited?: boolean
  pipeline?: PipelineStep[]
}

export interface Attachment {
  id: string
  name: string
  type: string
  size: number
  url?: string
  data?: string
  thumbnail?: string
}

export interface Conversation {
  id: string
  title: string
  messages: Message[]
  createdAt: number
  updatedAt: number
  pinned?: boolean
  folder?: string
  tags?: string[]
  modelSelection?: ModelSelection
  archived?: boolean
}

// ═══════════════════════════════════════════════════════════════════════════════
// PROJECTS - Cursor-like functionality
// ═══════════════════════════════════════════════════════════════════════════════

export interface ProjectFile {
  id: string
  name: string
  type: 'file' | 'folder'
  path: string
  content?: string
  size?: number
  mimeType?: string
  thumbnail?: string
  children?: ProjectFile[]
  createdAt: number
  updatedAt: number
  indexed?: boolean
  embeddings?: number[]
}

export interface Project {
  id: string
  name: string
  description?: string
  icon?: string
  color?: string
  files: ProjectFile[]
  conversations: string[] // conversation IDs
  memories: string[] // memory IDs
  settings?: ProjectSettings
  createdAt: number
  updatedAt: number
  lastAccessed: number
  pinned?: boolean
  tags?: string[]
}

export interface ProjectSettings {
  defaultModel?: ModelSelection
  contextFiles?: string[] // file paths to always include
  gitIntegration?: boolean
  autoSave?: boolean
  workspace?: string
}

// ═══════════════════════════════════════════════════════════════════════════════
// MEMORY SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════

export type MemoryType = 'user' | 'workspace' | 'chat' | 'project' | 'temporary' | 'long_term'

export interface Memory {
  id: string
  type: MemoryType
  content: string
  context?: string // Alias for content (compatibility)
  summary?: string
  tags?: string[]
  importance: number
  relevance?: number
  createdAt: number
  updatedAt: number
  lastAccessed: number
  expiresAt?: number
  projectId?: string
  conversationId?: string
  embeddings?: number[]
}

// ═══════════════════════════════════════════════════════════════════════════════
// AGENTS
// ═══════════════════════════════════════════════════════════════════════════════

export type AgentType = 
  | 'coding' 
  | 'writing' 
  | 'research' 
  | 'marketing' 
  | 'business' 
  | 'teacher' 
  | 'designer' 
  | 'architect' 
  | 'devops'
  | 'custom'

export interface Agent {
  id: string
  name: string
  type: AgentType
  description: string
  systemPrompt: string
  icon?: string
  color?: string
  modelSelection: ModelSelection
  temperature?: number
  capabilities?: AuraCapability[]
  tools?: string[]
  createdAt: number
  updatedAt: number
  builtIn?: boolean
}

// ═══════════════════════════════════════════════════════════════════════════════
// THEMES
// ═══════════════════════════════════════════════════════════════════════════════

export type ThemeMode = 'dark' | 'light' | 'midnight' | 'oled' | 'glass' | 'cyber' | 'minimal' | 'aura-blue' | 'aura-purple' | 'aura-emerald' | 'system'

export interface Theme {
  id: string
  name: string
  mode: ThemeMode
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    surface: string
    text: string
    textSecondary: string
    border: string
  }
  effects?: {
    blur?: number
    opacity?: number
    shadows?: boolean
    animations?: boolean
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// VIEW MODES
// ═══════════════════════════════════════════════════════════════════════════════

export type ViewMode =
  | 'chat'
  | 'agent'
  | 'code'
  | 'design'
  | 'search'
  | 'memory'
  | 'settings'
  | 'projects'
  | 'knowledge'

// ═══════════════════════════════════════════════════════════════════════════════
// USER PREFERENCES
// ═══════════════════════════════════════════════════════════════════════════════

export interface UserPreferences {
  theme: ThemeMode
  accentColor: string
  fontSize: number
  messageSpacing: 'compact' | 'normal' | 'relaxed'
  codeTheme: string
  developerMode: boolean
  showModelInMessages: boolean
  showTimestamps: boolean
  soundEffects: boolean
  notifications: boolean
  autoSave: boolean
  sendOnEnter: boolean
  spellCheck: boolean
  language?: string
  responseLength?: 'short' | 'medium' | 'long' | 'concise' | 'balanced' | 'detailed'
  showPipeline?: boolean
  enableMemory?: boolean
}

// ═══════════════════════════════════════════════════════════════════════════════
// VOICE SETTINGS
// ═══════════════════════════════════════════════════════════════════════════════

export interface VoiceSettings {
  enabled: boolean
  provider: 'browser' | 'elevenlabs' | 'openai'
  voice: string
  speed: number
  pitch: number
  volume: number
  autoPlay: boolean
  apiKey?: string
  continuousMode?: boolean
  bargeIn?: boolean
  emotionAware?: boolean
  wakeWordEnabled?: boolean
  wakeWord?: string
  sttEngine?: 'browser' | 'whisper' | 'deepgram'
  ttsEngine?: 'browser' | 'elevenlabs' | 'openai'
  language?: string
  vadSensitivity?: number
}

// ═══════════════════════════════════════════════════════════════════════════════
// DEVELOPER DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════════

export interface DevLogEntry {
  id: string
  timestamp: number
  type: 'request' | 'response' | 'error' | 'routing'
  provider?: AIProvider
  model?: string
  auraModel?: string
  prompt?: string
  response?: string
  tokens?: {
    input: number
    output: number
    total: number
  }
  latency?: number
  cost?: number
  error?: string
}

export interface DevDashboardStats {
  totalRequests: number
  totalTokens: number
  totalCost: number
  avgLatency: number
  providerBreakdown: Record<string, number>
  modelBreakdown: Record<string, number>
  errorRate: number
}

// ═══════════════════════════════════════════════════════════════════════════════
// PLUGINS
// ═══════════════════════════════════════════════════════════════════════════════

export interface PluginManifest {
  id: string
  name: string
  version: string
  description: string
  author: string
  enabled: boolean
  entrypoint: string
  permissions: string[]
  icon?: string
}

// ═══════════════════════════════════════════════════════════════════════════════
// PIPELINE STEPS (for visual feedback)
// ═══════════════════════════════════════════════════════════════════════════════

export interface PipelineStep {
  id: string
  label: string
  status: 'pending' | 'active' | 'complete' | 'error' | 'skipped'
  provider?: AIProvider
  model?: string
  stage?: string
  startTime?: number
  endTime?: number
}

// Legacy alias
export type PipelineStage = PipelineStep

// ═══════════════════════════════════════════════════════════════════════════════
// SEARCH
// ═══════════════════════════════════════════════════════════════════════════════

export interface SearchResult {
  type: 'conversation' | 'message' | 'file' | 'memory' | 'project'
  id: string
  title: string
  content: string
  timestamp?: number
  relevance: number
  metadata?: Record<string, any>
}

// ═══════════════════════════════════════════════════════════════════════════════
// CHAT OPTIONS & EVENTS (for existing code compatibility)
// ═══════════════════════════════════════════════════════════════════════════════

export interface ChatStartOptions {
  model?: string
  temperature?: number
  maxTokens?: number
  streaming?: boolean
  profileId?: string
}

export interface ChatEventPayload {
  type: 'token' | 'thinking' | 'done' | 'error' | 'abort' | 'pipeline'
  streamId?: string
  delta?: string
  text?: string
  message?: string
  pipeline?: PipelineStep[]
  data?: any
  error?: string
}

// ═══════════════════════════════════════════════════════════════════════════════
// WINDOW API (Electron)
// ═══════════════════════════════════════════════════════════════════════════════

export interface TestConnectionResult {
  success: boolean
  error?: string
  latency?: number
  latencyMs?: number
  model?: string
  supportsStreaming?: boolean
  supportsToolCalling?: boolean
  supportsVision?: boolean
  availableModels?: string[]
}

export interface AIStatus {
  connected: boolean
  provider?: AIProvider
  model?: string
  latency?: number
  hasApiKey?: boolean
}

export interface AuraAPI {
  chat: {
    start: (streamId: string, messages: Message[], options?: ChatStartOptions) => Promise<void>
    on: (event: string, callback: (payload: ChatEventPayload) => void) => () => void
    abort: (streamId: string) => Promise<void>
  }
  ai: {
    getConfig: () => Promise<AIConfig>
    saveConfig: (config: AIConfig) => Promise<void>
    setConfig: (config: Partial<AIConfig>) => Promise<void>
    chat: (messages: Message[], config?: Partial<AIConfig>) => Promise<string>
    stream: (messages: Message[], onChunk: (chunk: string) => void, config?: Partial<AIConfig>) => Promise<void>
    getStatus: () => Promise<AIStatus>
    getPresets: () => Promise<ModelPreset[]>
  }
  profiles: {
    list: () => Promise<APIProfile[]>
    create: (profile: Partial<APIProfile>) => Promise<APIProfile>
    update: (id: string, updates: Partial<APIProfile>) => Promise<APIProfile>
    delete: (id: string) => Promise<void>
    getActive: () => Promise<APIProfile | null>
    setActive: (id: string) => Promise<void>
    test: (profileOrId: string | APIProfile) => Promise<TestConnectionResult>
    testConnection: (profileOrId: string | APIProfile) => Promise<TestConnectionResult>
    duplicate: (id: string) => Promise<APIProfile>
    setDefault: (id: string) => Promise<void>
    enable: (id: string, enabled: boolean) => Promise<void>
    exportAll: () => Promise<string>
    importAll: (json: string) => Promise<void>
    backup: () => Promise<string>
  }
  models: {
    list: () => Promise<SavedModel[]>
    add: (model: Omit<SavedModel, 'id'>) => Promise<SavedModel>
    update: (id: string, updates: Partial<SavedModel>) => Promise<SavedModel>
    delete: (id: string) => Promise<void>
    togglePin: (id: string) => Promise<void>
    toggleFavorite: (id: string) => Promise<void>
    exportAll: () => Promise<string>
    importAll: (json: string) => Promise<void>
    virtual: {
      list: () => Promise<AuraVirtualModel[]>
      create: (model: Omit<AuraVirtualModel, 'id' | 'builtIn'>) => Promise<AuraVirtualModel>
      update: (id: string, updates: Partial<AuraVirtualModel>) => Promise<AuraVirtualModel>
      delete: (id: string) => Promise<void>
      export: (id: string) => Promise<string>
      import: (json: string) => Promise<AuraVirtualModel>
    }
  }
  memory: {
    list: () => Promise<Memory[]>
    create: (memory: Omit<Memory, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Memory>
    update: (id: string, updates: Partial<Memory>) => Promise<Memory>
    delete: (id: string) => Promise<void>
  }
  projects: {
    list: () => Promise<Project[]>
    create: (project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Project>
    update: (id: string, updates: Partial<Project>) => Promise<Project>
    delete: (id: string) => Promise<void>
    uploadFile: (projectId: string, file: File) => Promise<ProjectFile>
    deleteFile: (projectId: string, fileId: string) => Promise<void>
  }
  agents: {
    list: () => Promise<Agent[]>
    create: (agent: Omit<Agent, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Agent>
    update: (id: string, updates: Partial<Agent>) => Promise<Agent>
    delete: (id: string) => Promise<void>
  }
  search: {
    global: (query: string) => Promise<SearchResult[]>
  }
  themes: {
    list: () => Promise<Theme[]>
    apply: (themeId: string) => Promise<void>
  }
  window: {
    minimize: () => void
    maximize: () => void
    close: () => void
    toggleDevTools: () => void
  }
  routing?: {
    getConfig: () => Promise<any>
    setConfig: (config: any) => Promise<void>
    get: () => Promise<any>
    set: (config: any) => Promise<void>
  }
  voice?: {
    getSettings: () => Promise<VoiceSettings>
    setSettings: (settings: Partial<VoiceSettings>) => Promise<void>
  }
  devlogs?: {
    list: () => Promise<DevLogEntry[]>
    clear: () => Promise<void>
    stats: () => Promise<DevDashboardStats>
  }
  plugins?: {
    list: () => Promise<PluginManifest[]>
  }
  onToggleCommandPalette?: (callback: () => void) => () => void
}

declare global {
  interface Window {
    aura?: AuraAPI
  }
}
