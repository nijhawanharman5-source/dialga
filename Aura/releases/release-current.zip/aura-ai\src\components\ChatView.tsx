import { useEffect, useMemo, useRef, useCallback } from 'react'
import { motion } from 'framer-motion'
import { useAuraStore } from '@/store'
import { streamChat } from '@/services/ai'
import { resolveSelection } from '@/services/auraModels'
import type { Message, ModelSelection, PipelineStep, APIProfile, AuraVirtualModel, AIMode, Attachment } from '@/types'
import { ChatComposer } from './ChatComposer'
import { MessageBubble } from './MessageBubble'
import { ModelPicker } from './ModelPicker'
import { StatusStrip } from './StatusStrip'
import { LoadingExperience } from './LoadingExperience'
import { IntelligenceModeBar } from './IntelligenceModeBar'

function id() {
  return `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`
}

const suggestions = [
  'Design Aura’s memory architecture with Neon and vector search',
  'Build a polished React component for a command palette',
  'Research the best way to add real-time voice mode',
  'Plan a desktop AI coding workspace like Cursor + Raycast',
]

export function ChatView() {
  const activeConversationId = useAuraStore(state => state.activeConversationId)
  const conversations = useAuraStore(state => state.conversations)
  const createConversation = useAuraStore(state => state.createConversation)
  const addMessage = useAuraStore(state => state.addMessage)
  const updateMessage = useAuraStore(state => state.updateMessage)
  const isStreaming = useAuraStore(state => state.isStreaming)
  const setStreaming = useAuraStore(state => state.setStreaming)
  const activeConversation = useAuraStore(state => state.activeConversation())
  const defaultModelSelection = useAuraStore(state => state.defaultModelSelection)
  const setDefaultModelSelection = useAuraStore(state => state.setDefaultModelSelection)
  const setConversationModelSelection = useAuraStore(state => state.setConversationModelSelection)
  const abortRef = useRef<null | (() => Promise<void>)>(null)
  const scrollRef = useRef<HTMLDivElement | null>(null)

  const modelSelection = activeConversation?.modelSelection ?? defaultModelSelection

  function changeModel(selection: ModelSelection) {
    // Remember the choice globally and pin it to the open conversation so
    // switching chats never silently changes an in-flight conversation's model.
    setDefaultModelSelection(selection)
    if (activeConversationId) setConversationModelSelection(activeConversationId, selection)
  }

  useEffect(() => {
    if (!activeConversationId && conversations.length === 0) createConversation()
  }, [activeConversationId, conversations.length, createConversation])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [activeConversation?.messages])

  const messages = activeConversation?.messages ?? []
  const hasMessages = messages.length > 0

  const subtitle = useMemo(() => {
    if (!hasMessages) return 'A deeply capable AI companion for thinking, coding, researching, and creating.'
    return activeConversation?.title ?? 'Conversation'
  }, [activeConversation?.title, hasMessages])

  // Function to determine the appropriate AI mode based on content
  const determineOptimalMode = useCallback((content: string): AIMode => {
    const lowerContent = content.toLowerCase()

    // Expert level indicators - complex reasoning, research, advanced topics
    const expertIndicators = [
      'research', 'analyze', 'compare', 'evaluate', 'assess', 'comprehensive',
      'detailed', 'in-depth', 'thorough', 'exhaustive', 'systematic',
      'methodology', 'framework', 'architecture', 'design', 'strategy',
      'optimize', 'optimization', 'performance', 'scalability', 'architecture',
      'machine learning', 'deep learning', 'neural network', 'algorithm',
      'mathematics', 'mathematical', 'proof', 'theorem', 'equation',
      'physics', 'chemistry', 'biology', 'engineering', 'architecture',
      'philosophy', 'ethics', 'logic', 'reasoning', 'deduction', 'induction',
      'hypothesis', 'theory', 'principle', 'concept', 'paradigm',
      'literature review', 'systematic review', 'meta-analysis',
      'comparative analysis', 'risk assessment', 'impact analysis',
      'feasibility study', 'cost-benefit analysis', 'roi',
      'business strategy', 'market analysis', 'competitive analysis',
      'financial modeling', 'statistical analysis', 'data science',
      'artificial intelligence', 'machine learning', 'deep learning',
      'neural network', 'reinforcement learning', 'supervised learning',
      'unsupervised learning', 'natural language processing', 'nlp',
      'computer vision', 'robotics', 'quantum computing', 'blockchain',
      'cryptography', 'cybersecurity', 'network security',
      'distributed systems', 'microservices', 'cloud computing',
      'devops', 'ci/cd', 'kubernetes', 'docker', 'microservices',
      'software architecture', 'design patterns', 'microservices',
      'event-driven architecture', 'serverless', 'api design',
      'database design', 'data modeling', 'etl', 'data warehousing',
      'business intelligence', 'analytics', 'dashboard', 'reporting',
      'machine learning model', 'deep learning model', 'neural network',
      'computer vision', 'natural language processing', 'reinforcement learning'
    ]

    // Deep level indicators - moderate complexity, some reasoning
    const deepIndicators = [
      'explain', 'explain how', 'explain why', 'how does', 'how work',
      'why does', 'what is the difference', 'compare and contrast',
      'pros and cons', 'advantages and disadvantages', 'benefits and drawbacks',
      'how to', 'tutorial', 'guide', 'walkthrough', 'step by step',
      'example', 'sample', 'demonstration', 'demo', 'walk through',
      'best practices', 'guidelines', 'recommendations', 'suggestions',
      'tips and tricks', 'how to improve', 'how to optimize',
      'troubleshoot', 'debug', 'fix', 'resolve', 'solution',
      'approach', 'method', 'technique', 'strategy', 'plan',
      'outline', 'structure', 'organize', 'structure', 'outline',
      'summarize', 'summary', 'abstract', 'overview', 'introduction',
      'background', 'context', 'history', 'evolution', 'development',
      'trend', 'pattern', 'trend analysis', 'forecast', 'prediction',
      'projection', 'estimate', 'calculate', 'compute', 'formula',
      'equation', 'algorithm', 'logic', 'reasoning', 'proof',
      'demonstrate', 'show', 'prove', 'verify', 'validate',
      'test', 'testing', 'validation', 'verification',
      'research', 'study', 'investigation', 'examination', 'analysis'
    ]

    // Smart level indicators - basic questions, simple tasks
    const smartIndicators = [
      'what is', 'what are', 'who is', 'who are', 'when is', 'when are',
      'where is', 'where are', 'why is', 'why are', 'how is', 'how are',
      'define', 'definition', 'meaning', 'explain', 'describe',
      'list', 'enumerate', 'name', 'identify', 'identify',
      'show me', 'tell me', 'give me', 'provide', 'supply',
      'give an example', 'example of', 'examples of',
      'simple', 'basic', 'easy', 'simple explanation',
      'brief overview', 'summary', 'tl;dr', 'in short',
      'yes or no', 'true or false', 'either or',
      'choose between', 'select', 'pick', 'choose',
      'which is better', 'which one', 'which is best',
      'compare', 'difference', 'different', 'difference between',
      'similar', 'similarity', 'alike', 'like',
      'opposite', 'opposite of', 'contrary', 'contrast',
      'pros', 'cons', 'advantage', 'disadvantage',
      'benefit', 'drawback', 'strength', 'weakness',
      'pro', 'con', 'plus', 'minus',
      'good', 'bad', 'better', 'worse', 'best', 'worst',
      'like', 'dislike', 'love', 'hate', 'prefer',
      'favorite', 'preferred', 'recommended', 'suggested',
      'popular', 'common', 'typical', 'usual', 'normal',
      'standard', 'regular', 'ordinary', 'average',
      'typical', 'usual', 'normal', 'standard', 'regular'
    ]

    // Fast level indicators - very simple, factual, quick answers
    const fastIndicators = [
      'what', 'who', 'when', 'where', 'why', 'how',
      'yes', 'no', 'true', 'false',
      'ok', 'okay', 'hi', 'hello', 'hey',
      'thanks', 'thank you', 'thx', 'ty',
      'please', 'pls', 'plz',
      'sorry', 'apologize', 'my bad',
      'lol', 'lmao', 'rofl', 'haha', 'hehe',
      'wow', 'omg', 'amazing', 'awesome', 'cool',
      'nice', 'good', 'great', 'awesome', 'fantastic',
      'bad', 'terrible', 'awful', 'horrible',
      'yes', 'yeah', 'yep', 'yup',
      'no', 'nah', 'nope',
      'maybe', 'perhaps', 'possibly',
      'i think', 'i believe', 'in my opinion',
      'according to', 'as per', 'based on',
      'according to the', 'as stated in',
      'according to research', 'studies show',
      'research shows', 'studies indicate',
      'data shows', 'statistics show',
      'according to data', 'based on data'
    ]

    // Count matches for each level
    let expertScore = 0
    let deepScore = 0
    let smartScore = 0
    let fastScore = 0

    // Check for expert indicators
    expertIndicators.forEach(indicator => {
      if (lowerContent.includes(indicator)) expertScore += 2
    })

    // Check for deep indicators
    deepIndicators.forEach(indicator => {
      if (lowerContent.includes(indicator)) deepScore += 1.5
    })

    // Check for smart indicators
    smartIndicators.forEach(indicator => {
      if (lowerContent.includes(indicator)) smartScore += 1
    })

    // Check for fast indicators
    fastIndicators.forEach(indicator => {
      if (lowerContent.includes(indicator)) fastScore += 0.5
    })

    // Additional scoring based on content characteristics
    const wordCount = content.split(/\s+/).length
    const sentenceCount = content.split(/[.!?]+/).filter(s => s.trim().length > 0).length
    const avgWordsPerSentence = sentenceCount > 0 ? wordCount / sentenceCount : 0

    // Longer, more complex sentences suggest higher complexity
    if (wordCount > 50) expertScore += 2
    else if (wordCount > 30) deepScore += 1.5
    else if (wordCount > 15) smartScore += 1

    if (avgWordsPerSentence > 25) expertScore += 1.5
    else if (avgWordsPerSentence > 15) deepScore += 1
    else if (avgWordsPerSentence > 8) smartScore += 0.5

    // Special indicators for specific domains
    // Code-related queries
    if (/```|function|class|var|let|const|=>|=>|\(\)|\[\]|{}|\.map\(|\.filter\(|\.reduce\(/.test(content)) {
      if (content.includes('algorithm') || content.includes('optimize') || content.includes('architecture')) {
        expertScore += 3
      } else if (content.includes('how to') || content.includes('tutorial') || content.includes('example')) {
        deepScore += 2
      } else {
        smartScore += 1
      }
    }

    // Math-related queries
    if (/\d+\s*[\+\-\*\/\^]\s*\d+|\([^)]*\)|\=\=|\!\=|\<\=|\>\=/g.test(content)) {
      if (content.includes('equation') || content.includes('formula') || content.includes('prove') || content.includes('theorem')) {
        expertScore += 2
      } else if (content.includes('calculate') || content.includes('solve') || content.includes('compute')) {
        deepScore += 1.5
      } else {
        smartScore += 1
      }
    }

    // Determine the highest scoring level
    const scores = {
      expert: expertScore,
      deep: deepScore,
      smart: smartScore,
      fast: fastScore
    }

    // Find the level with the highest score
    let maxScore = 0
    let bestMode: AIMode = 'fast' // default

    for (const [level, score] of Object.entries(scores)) {
      if (score > maxScore) {
        maxScore = score
        bestMode = level as AIMode
      }
    }

    // Ensure we never return 'auto' - that's handled in the UI
    return bestMode
  }, [])

  const send = useCallback(async (message: string | { text: string; attachments: Attachment[] }) => {
    // One stream at a time: a second send while streaming could interleave
    // profiles.setActive and chat:start across streams (wrong model race).
    if (useAuraStore.getState().isStreaming) return

    let conversationId = activeConversationId
    if (!conversationId) conversationId = createConversation()

    // Resolve the picked Aura/provider model to a concrete profile and make it
    // active before streaming. Uses the existing profiles bridge only — if
    // nothing resolves (no profiles yet), the backend keeps its own default.
    // setActive is called unconditionally: the renderer's activeProfileId is a
    // best-effort mirror and must not gate the authoritative backend switch.
    let resolvedProfileId: string | undefined
    // Aura-branded label shown on the finished message — never the raw provider model id.
    let modelLabel = 'Aura'
    try {
      const state = useAuraStore.getState()
      const selection = state.conversations.find(c => c.id === conversationId)?.modelSelection ?? state.defaultModelSelection
      let profile: APIProfile | undefined
      let virtualModel: AuraVirtualModel | undefined

      if (selection.kind === 'aura') {
        virtualModel = state.virtualModels.find(m => m.id === selection.id)
        if (virtualModel) modelLabel = virtualModel.name
      } else {
        profile = state.profiles.find(p => p.id === selection.id)
        if (profile) modelLabel = profile.displayName
      }

      if (profile) {
        resolvedProfileId = profile.id
        await window.aura?.profiles.setActive(profile.id)
        state.setActiveProfileId(profile.id)
      }
    } catch (error) {
      console.warn('Model resolution failed, using active profile:', error)
    }

    // Extract text content for the user message
    const textContent = typeof message === 'string' ? message : message.text
    const attachments = typeof message === 'string' ? undefined : message.attachments

    const userMessage: Message = {
      id: id(),
      role: 'user',
      content: textContent,
      timestamp: Date.now(),
      attachments: attachments,
    }
    const assistantMessage: Message = {
      id: id(),
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    }

    const history = [...(useAuraStore.getState().conversations.find(c => c.id === conversationId)?.messages ?? []), userMessage]

    addMessage(conversationId, userMessage)
    addMessage(conversationId, assistantMessage)
    setStreaming(true)

    try {
      const stream = await streamChat(history, {
        onToken: token => {
          const current = useAuraStore
            .getState()
            .conversations.find(c => c.id === conversationId)
            ?.messages.find(m => m.id === assistantMessage.id)
          updateMessage(conversationId!, assistantMessage.id, {
            content: `${current?.content ?? ''}${token}`,
          })
        },
        onThinking: thinking => {
          const current = useAuraStore
            .getState()
            .conversations.find(c => c.id === conversationId)
            ?.messages.find(m => m.id === assistantMessage.id)
          updateMessage(conversationId!, assistantMessage.id, {
            thinking: `${current?.thinking ?? ''}${thinking}`,
          })
        },
        onPipeline: (steps: PipelineStep[]) => {
          useAuraStore.getState().setActivePipeline(steps)
          updateMessage(conversationId!, assistantMessage.id, {
            pipeline: steps,
          })
        },
        onDone: (fullResponse, payload) => {
          try {
            updateMessage(conversationId!, assistantMessage.id, {
              content: fullResponse,
              isStreaming: false,
              thinking: undefined, // Clear thinking state to stop animation
              model: modelLabel,
            })
            useAuraStore.getState().setActivePipeline(null)
            setStreaming(false)
            abortRef.current = null
          } catch (error) {
            console.error('Error in onDone callback:', error)
            // Ensure streaming state is reset even if updateMessage fails
            useAuraStore.getState().setActivePipeline(null)
            setStreaming(false)
            abortRef.current = null
          }
        },
        onError: error => {
          try {
            // Provide user-friendly error messages
            const userFriendlyError = error.message.includes('Failed to fetch')
              ? 'Unable to connect to AI service. Please check your internet connection and try again.'
              : error.message.includes('timeout')
                ? 'The request took too long to complete. Please try again with a simpler query.'
                : error.message;

            updateMessage(conversationId!, assistantMessage.id, {
              isStreaming: false,
              error: userFriendlyError,
            })
            useAuraStore.getState().setActivePipeline(null)
            setStreaming(false)
            abortRef.current = null
          } catch (error) {
            console.error('Error in onError callback:', error)
            // Ensure streaming state is reset even if updateMessage fails
            useAuraStore.getState().setActivePipeline(null)
            setStreaming(false)
            abortRef.current = null
          }
        },
        onAbort: () => {
          try {
            updateMessage(conversationId!, assistantMessage.id, {
              isStreaming: false,
            })
            useAuraStore.getState().setActivePipeline(null)
            setStreaming(false)
            abortRef.current = null
          } catch (error) {
            console.error('Error in onAbort callback:', error)
            // Ensure streaming state is reset even if updateMessage fails
            useAuraStore.getState().setActivePipeline(null)
            setStreaming(false)
            abortRef.current = null
          }
        },
      }, resolvedProfileId ? { profileId: resolvedProfileId } : undefined)
      abortRef.current = stream.abort
    } catch (error) {
      // Provide user-friendly error messages
      const userFriendlyError = error instanceof Error
        ? error.message.includes('Failed to fetch')
          ? 'Unable to connect to AI service. Please check your internet connection and try again.'
          : error.message.includes('timeout')
            ? 'The request took too long to complete. Please try again with a simpler query.'
            : error.message
        : 'An unexpected error occurred. Please try again.';

      updateMessage(conversationId, assistantMessage.id, {
        isStreaming: false,
        error: userFriendlyError,
      })
      setStreaming(false)
      abortRef.current = null
    }
  }, [])

  const abort = useCallback(async () => {
    await abortRef.current?.()
    setStreaming(false)
  }, [])

  return (
    <section className="flex h-full min-w-0 flex-1 flex-col">
      <header className="flex shrink-0 items-center justify-between gap-4 border-b border-white/6 px-6 py-4">
        <div className="min-w-0">
          <h1 className="truncate text-2xl font-semibold tracking-tight text-white">{hasMessages ? activeConversation?.title : 'How can I amplify you today?'}</h1>
          <p className="mt-1 truncate text-sm text-white/38">{subtitle}</p>
        </div>
        <div className="flex shrink-0 items-center gap-3">
          <ModelPicker value={modelSelection} onChange={changeModel} />
          <StatusStrip />
        </div>
      </header>

      <div className="relative min-h-0 flex-1">
        <div ref={scrollRef} className="h-full overflow-y-auto py-7">
          {!hasMessages ? (
            <div className="mx-auto flex min-h-full max-w-4xl flex-col items-center justify-center px-6 text-center">
              <motion.div
                animate={{ opacity: 1, y: 0, scale: 1 }}
                className="flex h-24 w-24 items-center justify-center rounded-[2rem] border border-white/15 bg-white/8 shadow-2xl shadow-aura-950/50 backdrop-blur-2xl"
                initial={{ opacity: 0, y: 12, scale: 0.96 }}
              >
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-aura-300 via-fuchsia-300 to-pink-300 shadow-[0_0_42px_rgba(124,111,255,0.8)]" />
              </motion.div>
              <motion.h2 animate={{ opacity: 1, y: 0 }} className="mt-8 text-5xl font-semibold tracking-tight text-white" initial={{ opacity: 0, y: 12 }}>
                Meet Aura
              </motion.h2>
              <motion.p animate={{ opacity: 1, y: 0 }} className="mt-4 max-w-2xl text-balance text-lg leading-8 text-white/52" initial={{ opacity: 0, y: 12 }} transition={{ delay: 0.06 }}>
                Your premium AI operating system for natural conversation, coding, research, creation, planning, and long-running work.
              </motion.p>
              <div className="mt-9 grid w-full gap-3 sm:grid-cols-2">
                {suggestions.map(suggestion => (
                  <button
                    className="rounded-3xl border border-white/10 bg-white/[0.045] p-4 text-left text-sm leading-6 text-white/58 transition hover:border-aura-400/40 hover:bg-aura-500/10 hover:text-white"
                    key={suggestion}
                    onClick={() => send(suggestion)}
                    type="button"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="mx-auto flex max-w-5xl flex-col gap-6 pb-28">
              {messages.map(message => <MessageBubble key={message.id} message={message} />)}
            </div>
          )}
        </div>
      </div>

      <ChatComposer disabled={isStreaming} isStreaming={isStreaming} onAbort={abort} onSend={send} />
      {/* Intelligence Mode Bar */}
      <IntelligenceModeBar />
      {/* Creative Loading Experience */}
      <LoadingExperience taskType={getTaskType(activeConversationId ? useAuraStore.getState().conversations.find(c => c.id === activeConversationId)?.messages.slice(-1)[0]?.content ?? '' : '')} />
    </section>
  )
}

const getTaskType = useCallback((content: string): string => {
  const lower = content.toLowerCase()

  if (
    lower.includes('code') ||
    lower.includes('function') ||
    lower.includes('class') ||
    lower.includes('debug') ||
    lower.includes('fix bug') ||
    lower.includes('implement') ||
    lower.includes('refactor') ||
    lower.includes('endpoint') ||
    lower.includes('import ') ||
    lower.includes('export ') ||
    lower.includes('```')
  ) {
    return 'coding'
  }

  if (
    lower.includes('plan') ||
    lower.includes('architecture') ||
    lower.includes('design') ||
    lower.includes('structure') ||
    lower.includes('outline') ||
    lower.includes('strategy') ||
    lower.includes('roadmap') ||
    lower.includes('step by step')
  ) {
    return 'planning'
  }

  if (
    lower.includes('embedding') ||
    lower.includes('vector search') ||
    lower.includes('semantic search') ||
    lower.includes('similarity search')
  ) {
    return 'embeddings'
  }

  if (
    lower.includes('image') ||
    lower.includes('picture') ||
    lower.includes('photo') ||
    lower.includes('diagram') ||
    lower.includes('screenshot') ||
    lower.includes('this image')
  ) {
    return 'vision'
  }

  return 'default'
}, [])
