import Anthropic from '@anthropic-ai/sdk'
import OpenAI from 'openai'
import type {
  AIConfig,
  AIMode,
  APIProfile,
  ModelPreset,
  PipelineStage,
  PipelineStep,
  TestConnectionResult,
} from './aiConfig'
import { addDevLog } from './aiConfig'

interface RendererMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
}

export interface StreamCallbacks {
  onToken: (token: string) => void
  onThinking?: (thinking: string) => void
  onDone: (text: string, model?: string, usage?: { input: number; output: number; total: number }) => void
  onError: (error: Error) => void
  onAbort?: () => void
  onPipeline?: (steps: PipelineStep[]) => void
}

interface StreamUsage {
  input: number
  output: number
  total: number
}

interface StreamResult {
  text: string
  model?: string
  usage?: StreamUsage
  aborted?: boolean
}

interface ModeOverrides {
  temperature: number
  maxTokens: number
  systemAddendum?: string
  pipelineDepth: 'none' | 'light' | 'full'
}

const MODE_OVERRIDES: Record<AIMode, ModeOverrides> = {
  fast: {
    temperature: 0.3,
    maxTokens: 2048,
    pipelineDepth: 'none',
  },
  balanced: {
    temperature: 0.5,
    maxTokens: 4096,
    pipelineDepth: 'light',
    systemAddendum: '\n\nBalance speed and quality. Be thorough but efficient.',
  },
  think: {
    temperature: 0.7,
    maxTokens: 8192,
    pipelineDepth: 'full',
    systemAddendum: '\n\nThink deeply about the request. Consider edge cases and provide well-structured, comprehensive answers.',
  },
  plan: {
    temperature: 0.7,
    maxTokens: 12288,
    pipelineDepth: 'full',
    systemAddendum: '\n\nIMPORTANT: Break the task into clear, numbered steps before writing any code. Plan first, then implement.',
  },
  max: {
    temperature: 0.8,
    maxTokens: 16384,
    pipelineDepth: 'full',
    systemAddendum: '\n\nProvide maximum depth and quality. Consider all angles, edge cases, and best practices.',
  },
  bypass: {
    temperature: 1,
    maxTokens: 32768,
    pipelineDepth: 'none',
    systemAddendum: '\n\nExecute the requested workflow directly. Skip unnecessary confirmations. Use tools aggressively. Never reduce answer quality.',
  },
}

export const PROVIDER_BASE_URLS: Record<string, string> = {
  anthropic: 'https://api.anthropic.com',
  openai: 'https://api.openai.com/v1',
  moonshot: 'https://api.moonshot.ai/v1',
  zai: 'https://api.z.ai/api/paas/v4/',
  groq: 'https://api.groq.com/openai/v1',
  openrouter: 'https://openrouter.ai/api/v1',
  nvidia: 'https://integrate.api.nvidia.com/v1',
  gemini: 'https://generativelanguage.googleapis.com/v1beta/openai/',
  ollama: 'http://localhost:11434/v1',
  lmstudio: 'http://localhost:1234/v1',
  localai: 'http://localhost:8080/v1',
  vllm: 'http://localhost:8000/v1',
  custom: '',
}

export const PROVIDER_PRESETS: ModelPreset[] = [
  { provider: 'anthropic', label: 'Claude Opus 4', modelId: 'claude-opus-4-8', baseURL: 'https://api.anthropic.com' },
  { provider: 'anthropic', label: 'Claude Sonnet 5', modelId: 'claude-sonnet-5', baseURL: 'https://api.anthropic.com' },
  { provider: 'anthropic', label: 'Claude Haiku 4.5', modelId: 'claude-haiku-4-5', baseURL: 'https://api.anthropic.com' },
  { provider: 'openai', label: 'GPT-4o', modelId: 'gpt-4o', baseURL: 'https://api.openai.com/v1' },
  { provider: 'openai', label: 'GPT-4o Mini', modelId: 'gpt-4o-mini', baseURL: 'https://api.openai.com/v1' },
  { provider: 'openai', label: 'o3', modelId: 'o3', baseURL: 'https://api.openai.com/v1' },
  { provider: 'moonshot', label: 'Kimi K2.6', modelId: 'kimi-k2.6', baseURL: 'https://api.moonshot.ai/v1' },
  { provider: 'moonshot', label: 'Kimi K2.5', modelId: 'kimi-k2.5', baseURL: 'https://api.moonshot.ai/v1' },
  { provider: 'zai', label: 'GLM-5.2', modelId: 'glm-5.2', baseURL: 'https://api.z.ai/api/paas/v4/' },
  { provider: 'groq', label: 'Llama 4 Maverick', modelId: 'llama-4-maverick', baseURL: 'https://api.groq.com/openai/v1' },
  { provider: 'groq', label: 'Llama 4 Scout', modelId: 'llama-4-scout', baseURL: 'https://api.groq.com/openai/v1' },
  { provider: 'groq', label: 'Qwen3 Coder', modelId: 'qwen3-coder', baseURL: 'https://api.groq.com/openai/v1' },
  { provider: 'openrouter', label: 'Qwen3 Coder', modelId: 'qwen/qwen3-coder', baseURL: 'https://openrouter.ai/api/v1' },
  { provider: 'openrouter', label: 'DeepSeek V4', modelId: 'deepseek/deepseek-v4', baseURL: 'https://openrouter.ai/api/v1' },
  { provider: 'openrouter', label: 'GPT OSS 120B', modelId: 'openai/gpt-oss-120b', baseURL: 'https://openrouter.ai/api/v1' },
  { provider: 'openrouter', label: 'Claude Opus 4.5', modelId: 'anthropic/claude-opus-4-5', baseURL: 'https://openrouter.ai/api/v1' },
  { provider: 'openrouter', label: 'Llama 4', modelId: 'meta-llama/llama-4', baseURL: 'https://openrouter.ai/api/v1' },
  { provider: 'openrouter', label: 'Nemotron', modelId: 'nvidia/nemotron', baseURL: 'https://openrouter.ai/api/v1' },
  { provider: 'nvidia', label: 'DeepSeek V4 Pro', modelId: 'deepseek/deepseek-v4-pro', baseURL: 'https://integrate.api.nvidia.com/v1' },
  { provider: 'nvidia', label: 'Nemotron 3 Ultra 550B', modelId: 'nvidia/nemotron-3-ultra-550b-a55b', baseURL: 'https://integrate.api.nvidia.com/v1' },
  { provider: 'nvidia', label: 'Nemotron 3 Super 120B', modelId: 'nvidia/nemotron-3-super-120b-a12b', baseURL: 'https://integrate.api.nvidia.com/v1' },
  { provider: 'gemini', label: 'Gemini 2.5 Pro', modelId: 'gemini-2.5-pro', baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/' },
  { provider: 'gemini', label: 'Gemini 2.5 Flash', modelId: 'gemini-2.5-flash', baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/' },
  { provider: 'ollama', label: 'Qwen 2.5', modelId: 'qwen2.5', baseURL: 'http://localhost:11434/v1' },
  { provider: 'ollama', label: 'DeepSeek R1', modelId: 'deepseek-r1', baseURL: 'http://localhost:11434/v1' },
  { provider: 'ollama', label: 'Llama 3.2', modelId: 'llama3.2', baseURL: 'http://localhost:11434/v1' },
  { provider: 'ollama', label: 'Mistral', modelId: 'mistral', baseURL: 'http://localhost:11434/v1' },
  { provider: 'lmstudio', label: 'Loaded Model', modelId: 'local-model', baseURL: 'http://localhost:1234/v1' },
  { provider: 'lmstudio', label: 'Qwen 2.5 Coder', modelId: 'qwen2.5-coder', baseURL: 'http://localhost:1234/v1' },
  { provider: 'lmstudio', label: 'DeepSeek Coder V2', modelId: 'deepseek-coder-v2', baseURL: 'http://localhost:1234/v1' },
  { provider: 'localai', label: 'GPT-4 Local', modelId: 'gpt-4', baseURL: 'http://localhost:8080/v1' },
  { provider: 'localai', label: 'Llama 3 Local', modelId: 'llama3', baseURL: 'http://localhost:8080/v1' },
  { provider: 'localai', label: 'Mistral Local', modelId: 'mistral', baseURL: 'http://localhost:8080/v1' },
  { provider: 'vllm', label: 'Served Model', modelId: 'default-model', baseURL: 'http://localhost:8000/v1' },
  { provider: 'vllm', label: 'Llama 4 Server', modelId: 'meta-llama/Llama-4', baseURL: 'http://localhost:8000/v1' },
  { provider: 'vllm', label: 'Qwen3 Server', modelId: 'Qwen/Qwen3', baseURL: 'http://localhost:8000/v1' },
]

const COST_PER_1M: Record<string, { input: number; output: number }> = {
  anthropic: { input: 15, output: 75 },
  openai: { input: 5, output: 15 },
  moonshot: { input: 0.95, output: 4 },
  zai: { input: 1.4, output: 4.4 },
  groq: { input: 0, output: 0 },
  openrouter: { input: 2, output: 6 },
  nvidia: { input: 3, output: 6 },
  gemini: { input: 1.25, output: 5 },
  ollama: { input: 0, output: 0 },
  lmstudio: { input: 0, output: 0 },
  localai: { input: 0, output: 0 },
  vllm: { input: 0, output: 0 },
  custom: { input: 0, output: 0 },
}

function estimateCost(provider: string, promptTokens: number, completionTokens: number): number {
  const rates = COST_PER_1M[provider] ?? COST_PER_1M.custom
  return (promptTokens * rates.input + completionTokens * rates.output) / 1_000_000
}

const PIPELINE_STAGES: PipelineStage[] = [
  'intent',
  'context',
  'memory',
  'planning',
  'tools',
  'execution',
  'review',
  'response',
]

export const STAGE_LABELS: Record<PipelineStage, string> = {
  intent: 'Intent Analysis',
  context: 'Context Retrieval',
  memory: 'Memory Retrieval',
  planning: 'Planning',
  tools: 'Tool Selection',
  execution: 'Execution',
  review: 'Self-Review',
  response: 'Final Response',
}

function buildPipeline(mode: AIMode, hasMemory: boolean): PipelineStep[] {
  const depth = MODE_OVERRIDES[mode].pipelineDepth

  if (depth === 'none') {
    return [
      { stage: 'execution', status: 'active', summary: 'Processing request', timestamp: Date.now() },
      { stage: 'response', status: 'pending', timestamp: Date.now() },
    ]
  }

  return PIPELINE_STAGES.map(stage => {
    if (stage === 'memory' && !hasMemory) {
      return { stage, status: 'skipped', summary: 'No relevant memories', timestamp: Date.now() }
    }

    if (depth === 'light' && (stage === 'tools' || stage === 'review')) {
      return { stage, status: 'skipped', timestamp: Date.now() }
    }

    return { stage, status: 'pending', timestamp: Date.now() }
  })
}

function advancePipeline(steps: PipelineStep[], activeStage: PipelineStage): PipelineStep[] {
  const activeIndex = PIPELINE_STAGES.indexOf(activeStage)
  return steps.map(step => {
    const currentIndex = PIPELINE_STAGES.indexOf(step.stage)
    if (step.stage === activeStage) return { ...step, status: 'active', timestamp: Date.now() }
    if (currentIndex < activeIndex && step.status !== 'skipped') {
      return { ...step, status: 'complete', timestamp: Date.now() }
    }
    return step
  })
}

function normalizeAnthropicBaseURL(baseURL: string): string | undefined {
  const trimmed = baseURL.trim().replace(/\/$/, '')
  if (!trimmed || trimmed === 'https://api.anthropic.com') return undefined
  return trimmed.endsWith('/v1') ? trimmed.slice(0, -3) : trimmed
}

function shouldOmitTemperature(provider: string, model: string): boolean {
  const normalizedModel = model.toLowerCase()
  return provider === 'moonshot' && (normalizedModel.startsWith('kimi-k2.5') || normalizedModel.startsWith('kimi-k2.6'))
}

function hasAuthorizationHeader(headers: Record<string, string>): boolean {
  return Object.keys(headers).some(key => key.toLowerCase() === 'authorization')
}

function resolveChatCompletionsURL(baseURL: string): string {
  const trimmed = baseURL.trim().replace(/\/$/, '')
  if (!trimmed) throw new Error('Base URL is required for a custom/company API.')
  if (/\/chat\/completions$/i.test(trimmed)) return trimmed
  return `${trimmed}/chat/completions`
}

function appendQueryParameters(url: string, params: Record<string, string>): string {
  const next = new URL(url)
  for (const [key, value] of Object.entries(params)) {
    if (!key.trim()) continue
    next.searchParams.set(key, value)
  }
  return next.toString()
}

function extractErrorMessage(payload: unknown, fallback: string): string {
  if (typeof payload === 'string' && payload.trim()) return payload
  if (payload && typeof payload === 'object') {
    const record = payload as Record<string, unknown>
    if (record.error && typeof record.error === 'object') {
      const errorRecord = record.error as Record<string, unknown>
      if (typeof errorRecord.message === 'string' && errorRecord.message.trim()) return errorRecord.message
    }
    if (typeof record.message === 'string' && record.message.trim()) return record.message
  }
  return fallback
}

async function createCustomChatCompletion(
  config: AIConfig | APIProfile,
  messages: OpenAI.Chat.ChatCompletionMessageParam[],
  signal: AbortSignal,
  stream: boolean,
  temperature: number,
  maxTokens: number
): Promise<Response> {
  if (!config.baseURL?.trim()) throw new Error('Base URL is required for a custom/company API.')
  if (!config.model?.trim()) throw new Error('Model is required for a custom/company API.')

  const extraHeaders = (config as APIProfile).customHeaders ?? (config as AIConfig).customHeaders ?? {}
  const queryParams = (config as APIProfile).queryParameters ?? {}
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...extraHeaders,
  }

  if (config.apiKey && !hasAuthorizationHeader(headers)) {
    headers.Authorization = `Bearer ${config.apiKey}`
  }

  const url = appendQueryParameters(resolveChatCompletionsURL(config.baseURL), queryParams)
  const response = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      model: config.model,
      messages,
      temperature: shouldOmitTemperature(config.provider, config.model) ? undefined : temperature,
      max_tokens: maxTokens,
      top_p: config.topP,
      stream,
    }),
    signal,
  })

  if (!response.ok) {
    const text = await response.text()
    let payload: unknown = text
    try {
      payload = JSON.parse(text)
    } catch {
      payload = text
    }
    throw new Error(extractErrorMessage(payload, `${response.status} ${response.statusText}`))
  }

  return response
}

async function streamCustomOpenAICompat(
  config: AIConfig | APIProfile,
  messages: RendererMessage[],
  system: string,
  temperature: number,
  maxTokens: number,
  abortSignal: AbortSignal,
  callbacks: StreamCallbacks
): Promise<void> {
  const openaiMessages: OpenAI.Chat.ChatCompletionMessageParam[] = [
    { role: 'system', content: system },
    ...messages.map(message => ({
      role: message.role as 'user' | 'assistant',
      content: message.content,
    })),
  ]

  const response = await createCustomChatCompletion(config, openaiMessages, abortSignal, true, temperature, maxTokens)
  if (!response.body) throw new Error('Custom/company API did not return a response stream.')

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let text = ''
  let lastModel: string | undefined

  while (true) {
    const { value, done } = await reader.read()
    buffer += decoder.decode(value ?? new Uint8Array(), { stream: !done })

    let boundary = buffer.indexOf('\n\n')
    while (boundary !== -1) {
      const chunk = buffer.slice(0, boundary)
      buffer = buffer.slice(boundary + 2)

      const data = chunk
        .split(/\r?\n/)
        .filter(line => line.startsWith('data:'))
        .map(line => line.slice(5).trim())
        .join('')

      if (data && data !== '[DONE]') {
        const parsed = JSON.parse(data) as {
          model?: string
          choices?: Array<{ delta?: { content?: string }; message?: { content?: string } }>
        }
        lastModel = parsed.model ?? lastModel
        const delta = parsed.choices?.[0]?.delta?.content
          ?? parsed.choices?.[0]?.message?.content
          ?? ''
        if (delta) {
          text += delta
          callbacks.onToken(delta)
        }
      }

      boundary = buffer.indexOf('\n\n')
    }

    if (done) break
    if (abortSignal.aborted) {
      callbacks.onAbort?.()
      return
    }
  }

  if (abortSignal.aborted) {
    callbacks.onAbort?.()
    return
  }

  callbacks.onDone(text, lastModel)
}

export function profileToConfig(profile: APIProfile, aiMode: AIMode): AIConfig {
  return {
    provider: profile.provider,
    apiKey: profile.apiKey,
    baseURL: profile.baseURL,
    model: profile.model,
    organizationId: profile.organizationId,
    customHeaders: profile.customHeaders,
    temperature: profile.temperature,
    topP: profile.topP,
    maxTokens: profile.maxTokens,
    streaming: profile.streaming,
    reasoningEffort: 'none',
    contextLength: profile.contextLength,
    aiMode,
    savedModels: [],
    activeProfileId: profile.id,
  }
}

export async function streamCompletion(
  config: AIConfig | APIProfile,
  messages: RendererMessage[],
  systemPrompt: string,
  abortSignal: AbortSignal,
  callbacks: StreamCallbacks,
  options?: {
    profile?: APIProfile
    hasMemory?: boolean
    taskType?: string
  }
): Promise<void> {
  const mode = (config as AIConfig).aiMode ?? 'think'
  const overrides = MODE_OVERRIDES[mode]
  const temperature = (config as APIProfile).temperature ?? overrides.temperature
  const maxTokens = (config as APIProfile).maxTokens ?? overrides.maxTokens
  const fullSystem = overrides.systemAddendum ? systemPrompt + overrides.systemAddendum : systemPrompt
  const apiMessages = messages.filter(message => message.role !== 'system')
  const hasMemory = options?.hasMemory ?? false

  let pipeline = buildPipeline(mode, hasMemory)
  callbacks.onPipeline?.(advancePipeline(pipeline, 'intent'))

  if (overrides.pipelineDepth !== 'none') {
    const visibleStages = PIPELINE_STAGES.filter(stage => pipeline.find(step => step.stage === stage && step.status !== 'skipped'))
    for (const stage of visibleStages) {
      if (abortSignal.aborted) break
      if (stage === 'execution' || stage === 'response') continue
      pipeline = advancePipeline(pipeline, stage)
      callbacks.onPipeline?.(pipeline)
      await new Promise(resolve => setTimeout(resolve, 80))
    }
  }

  pipeline = advancePipeline(pipeline, 'execution')
  callbacks.onPipeline?.(pipeline)

  const startTime = Date.now()
  const profile = options?.profile
  const provider = config.provider
  const latestRequest = apiMessages[apiMessages.length - 1]?.content?.slice(0, 200) ?? ''

  try {
    if (provider === 'anthropic') {
      await streamAnthropic(config, apiMessages, fullSystem, temperature, maxTokens, abortSignal, callbacks)
    } else {
      await streamOpenAICompat(config, apiMessages, fullSystem, temperature, maxTokens, abortSignal, callbacks)
    }

    if (profile) {
      pipeline = advancePipeline(pipeline, 'response')
      callbacks.onPipeline?.(pipeline)
      addDevLog({
        type: 'response',
        profileId: profile.id,
        profileName: profile.displayName,
        provider: profile.provider,
        model: config.model,
        latencyMs: Date.now() - startTime,
        status: 'success',
        requestPreview: latestRequest,
        responsePreview: '',
        mode,
      })
    }
  } catch (error) {
    if (abortSignal.aborted) {
      callbacks.onAbort?.()
      if (profile) {
        addDevLog({
          type: 'error',
          profileId: profile.id,
          profileName: profile.displayName,
          provider: profile.provider,
          model: config.model,
          latencyMs: Date.now() - startTime,
          status: 'aborted',
          requestPreview: latestRequest,
          responsePreview: '',
          mode,
        })
      }
      return
    }

    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    callbacks.onError(error instanceof Error ? error : new Error(errorMessage))

    if (profile) {
      addDevLog({
        type: 'error',
        profileId: profile.id,
        profileName: profile.displayName,
        provider: profile.provider,
        model: config.model,
        latencyMs: Date.now() - startTime,
        status: 'error',
        errorMessage,
        requestPreview: latestRequest,
        responsePreview: '',
        mode,
      })
    }
  }
}

async function streamAnthropic(
  config: AIConfig | APIProfile,
  messages: RendererMessage[],
  system: string,
  temperature: number,
  maxTokens: number,
  abortSignal: AbortSignal,
  callbacks: StreamCallbacks
): Promise<void> {
  const extraHeaders = (config as APIProfile).customHeaders ?? (config as AIConfig).customHeaders ?? {}
  const queryParams = (config as APIProfile).queryParameters ?? {}

  const client = new Anthropic({
    apiKey: config.apiKey,
    baseURL: normalizeAnthropicBaseURL(config.baseURL),
    timeout: (config as APIProfile).timeout ?? 10 * 60 * 1000,
    maxRetries: (config as APIProfile).retryCount ?? 2,
    defaultHeaders: extraHeaders,
  })

  let text = ''
  let thinking = ''

  const anthropicMessages = messages.map(message => ({
    role: message.role as 'user' | 'assistant',
    content: message.content,
  }))

  const stream = client.messages.stream(
    {
      model: config.model,
      max_tokens: maxTokens,
      temperature,
      system,
      messages: anthropicMessages,
      ...queryParams,
    },
    { signal: abortSignal }
  )

  for await (const event of stream) {
    if (abortSignal.aborted) break
    if (event.type !== 'content_block_delta') continue

    if (event.delta.type === 'text_delta') {
      text += event.delta.text
      callbacks.onToken(event.delta.text)
    }

    if (event.delta.type === 'thinking_delta') {
      thinking += event.delta.thinking
      callbacks.onThinking?.(event.delta.thinking)
    }
  }

  if (abortSignal.aborted) {
    callbacks.onAbort?.()
    return
  }

  const final = await stream.finalMessage()
  callbacks.onDone(text || thinking, final.model, {
    input: final.usage.input_tokens,
    output: final.usage.output_tokens,
    total: final.usage.input_tokens + final.usage.output_tokens,
  })
}

async function streamOpenAICompat(
  config: AIConfig | APIProfile,
  messages: RendererMessage[],
  system: string,
  temperature: number,
  maxTokens: number,
  abortSignal: AbortSignal,
  callbacks: StreamCallbacks
): Promise<void> {
  if (config.provider === 'custom') {
    await streamCustomOpenAICompat(config, messages, system, temperature, maxTokens, abortSignal, callbacks)
    return
  }

  const defaultHeaders: Record<string, string> = {}

  if (config.provider === 'openrouter') {
    defaultHeaders['HTTP-Referer'] = 'https://aura.ai'
    defaultHeaders['X-Title'] = 'Aura'
  }

  const extraHeaders = (config as APIProfile).customHeaders ?? (config as AIConfig).customHeaders ?? {}
  const queryParams = (config as APIProfile).queryParameters ?? {}

  const client = new OpenAI({
    apiKey: config.apiKey || (['ollama', 'lmstudio', 'localai', 'vllm'].includes(config.provider) ? 'ollama' : 'missing-api-key'),
    baseURL: config.baseURL,
    organization: (config as AIConfig).organizationId || (config as APIProfile).organizationId || undefined,
    defaultHeaders: { ...defaultHeaders, ...extraHeaders },
    timeout: (config as APIProfile).timeout ?? 10 * 60 * 1000,
    maxRetries: (config as APIProfile).retryCount ?? 2,
  })

  const openaiMessages: OpenAI.Chat.ChatCompletionMessageParam[] = [
    { role: 'system', content: system },
    ...messages.map(message => ({
      role: message.role as 'user' | 'assistant',
      content: message.content,
    })),
  ]

  const completionParams: OpenAI.Chat.ChatCompletionCreateParamsStreaming = {
    model: config.model,
    messages: openaiMessages,
    temperature: shouldOmitTemperature(config.provider, config.model) ? undefined : temperature,
    max_tokens: maxTokens,
    top_p: config.topP,
    stream: true,
    ...queryParams,
  }

  const stream = await client.chat.completions.create(completionParams, { signal: abortSignal })
  let text = ''
  let lastModel: string | undefined

  for await (const chunk of stream) {
    if (abortSignal.aborted) break
    const delta = chunk.choices[0]?.delta?.content
    if (delta) {
      text += delta
      callbacks.onToken(delta)
    }
    if (chunk.model) lastModel = chunk.model
  }

  if (abortSignal.aborted) {
    callbacks.onAbort?.()
    return
  }

  callbacks.onDone(text, lastModel)
}

export async function testConnection(config: AIConfig | APIProfile): Promise<TestConnectionResult> {
  const start = Date.now()
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 15000)
  const provider = config.provider
  const apiKey = config.apiKey
  const baseURL = config.baseURL
  const model = config.model

  let availableModels: string[] | undefined
  let supportsStreaming = false
  let supportsToolCalling = false
  let supportsVision = false

  try {
    if (provider === 'custom') {
      if (!baseURL?.trim()) {
        clearTimeout(timeout)
        return { success: false, error: 'Base URL is required for a custom/company API.' }
      }
      if (!model?.trim()) {
        clearTimeout(timeout)
        return { success: false, error: 'Model is required for a custom/company API.' }
      }

      const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
        { role: 'user', content: 'Say "ok"' },
      ]

      const response = await createCustomChatCompletion(config, messages, controller.signal, false, 0.2, 16)
      const payload = await response.json() as {
        model?: string
        choices?: Array<{ message?: { content?: string } }>
      }

      try {
        const streamResponse = await createCustomChatCompletion(
          config,
          [{ role: 'user', content: 'Reply with ok' }],
          controller.signal,
          true,
          0.2,
          16
        )

        if (streamResponse.body) {
          const reader = streamResponse.body.getReader()
          const firstChunk = await reader.read()
          supportsStreaming = Boolean(firstChunk.value && firstChunk.value.length > 0)
          await reader.cancel()
        }
      } catch {
        supportsStreaming = false
      }

      supportsToolCalling = true
      supportsVision = model.includes('vision') || model.includes('vl') || model.includes('image')

      clearTimeout(timeout)
      return {
        success: true,
        latencyMs: Date.now() - start,
        model: payload.model || model,
        supportsStreaming,
        supportsToolCalling,
        supportsVision,
      }
    }

    if (provider === 'anthropic') {
      const client = new Anthropic({
        apiKey,
        baseURL: normalizeAnthropicBaseURL(baseURL),
        timeout: 15000,
        maxRetries: 0,
      })

      const response = await client.messages.create(
        {
          model,
          max_tokens: 5,
          messages: [{ role: 'user', content: 'Say "ok"' }],
        },
        { signal: controller.signal }
      )

      try {
        const stream = await client.messages.create(
          {
            model,
            max_tokens: 10,
            messages: [{ role: 'user', content: 'Hi' }],
            stream: true,
          },
          { signal: controller.signal }
        )

        for await (const event of stream) {
          if (event.type === 'content_block_delta') {
            supportsStreaming = true
            break
          }
        }
      } catch {
        supportsStreaming = false
      }

      supportsToolCalling = true
      supportsVision = model.includes('opus') || model.includes('sonnet') || model.includes('claude-3')

      clearTimeout(timeout)
      return {
        success: true,
        latencyMs: Date.now() - start,
        model: response.model,
        supportsStreaming,
        supportsToolCalling,
        supportsVision,
      }
    }

    const client = new OpenAI({
      apiKey: apiKey || 'ollama',
      baseURL,
      organization: (config as AIConfig).organizationId || undefined,
      defaultHeaders: (config as AIConfig).customHeaders,
      timeout: 15000,
      maxRetries: 0,
    })

    if (['ollama', 'lmstudio', 'localai', 'vllm'].includes(provider)) {
      try {
        const modelsList = await client.models.list()
        availableModels = modelsList.data.map(item => item.id)
      } catch {
        availableModels = undefined
      }
    }

    const testModel =
      availableModels && availableModels.length > 0 && (!model || model === 'local-model' || model === 'default-model')
        ? availableModels[0]
        : model

    const response = await client.chat.completions.create(
      { model: testModel, messages: [{ role: 'user', content: 'Say "ok"' }], max_tokens: 5 },
      { signal: controller.signal }
    )

    try {
      const stream = await client.chat.completions.create(
        { model: testModel, messages: [{ role: 'user', content: 'Hi' }], max_tokens: 10, stream: true },
        { signal: controller.signal }
      )
      for await (const chunk of stream) {
        if (chunk.choices[0]?.delta?.content) {
          supportsStreaming = true
          break
        }
      }
    } catch {
      supportsStreaming = false
    }

    supportsToolCalling = ['openai', 'moonshot', 'zai', 'openrouter', 'gemini', 'groq', 'nvidia'].includes(provider)
    supportsVision =
      testModel.includes('vision') ||
      testModel.includes('4o') ||
      testModel.includes('gpt-4') ||
      testModel.includes('claude') ||
      testModel.includes('gemini') ||
      testModel.includes('glm-5v') ||
      testModel.includes('kimi')

    clearTimeout(timeout)
    return {
      success: true,
      latencyMs: Date.now() - start,
      model: response.model || testModel,
      supportsStreaming,
      supportsToolCalling,
      supportsVision,
      availableModels,
    }
  } catch (error) {
    clearTimeout(timeout)
    const message = error instanceof Error ? error.message : 'Unknown error'

    if (message.includes('401') || message.includes('403') || message.toLowerCase().includes('authentication')) {
      return { success: false, error: 'Authentication failed. Check your API key.' }
    }
    if (message.includes('404') || message.toLowerCase().includes('not found')) {
      return { success: false, error: 'Model or endpoint not found. Check model name and base URL.' }
    }
    if (message.includes('ECONNREFUSED') || message.toLowerCase().includes('fetch')) {
      return { success: false, error: 'Connection refused. Check if the server is running.' }
    }
    if (message.toLowerCase().includes('timeout') || message.toLowerCase().includes('aborted')) {
      return { success: false, error: 'Connection timeout. The server took too long to respond.' }
    }

    return { success: false, error: message }
  }
}

export { estimateCost }
