import { AgentPanel } from '@/components/AgentPanel'
import { CodePanel } from '@/components/CodePanel'
import { CommandPalette } from '@/components/CommandPalette'
import { ChatView } from '@/components/ChatView'
import { DesignPanel } from '@/components/DesignPanel'
import { MemoryPanel } from '@/components/MemoryPanel'
import { SearchPanel } from '@/components/SearchPanel'
import { SettingsPanel } from '@/components/SettingsPanel'
import { Sidebar } from '@/components/Sidebar'
import { TitleBar } from '@/components/TitleBar'
import { useAuraStore } from '@/store'
import { useEffect } from 'react'

export default function App() {
  const viewMode = useAuraStore(state => state.viewMode)
  const setAIConfig = useAuraStore(state => state.setAIConfig)
  const setProfiles = useAuraStore(state => state.setProfiles)
  const setActiveProfileId = useAuraStore(state => state.setActiveProfileId)

  // Load AI config + profiles once on startup so the mode strip and the
  // chat model picker are correct before Settings is ever opened. The active
  // profile is seeded from the backend's persisted value (setProfiles only
  // guesses default/first) so the renderer mirror starts accurate.
  useEffect(() => {
    window.aura?.ai.getConfig().then(setAIConfig).catch(() => {})
    window.aura?.profiles.list()
      .then(profiles => {
        setProfiles(profiles)
        return window.aura?.profiles.getActive()
      })
      .then(active => { if (active) setActiveProfileId(active.id) })
      .catch(() => {})
  }, [setAIConfig, setProfiles, setActiveProfileId])

  return (
    <div className="relative h-screen overflow-hidden bg-surface-0 text-white">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-36 -top-40 h-[520px] w-[520px] rounded-full bg-aura-600/22 blur-3xl" />
        <div className="absolute right-[-160px] top-24 h-[560px] w-[560px] rounded-full bg-fuchsia-500/16 blur-3xl" />
        <div className="absolute bottom-[-220px] left-1/3 h-[480px] w-[480px] rounded-full bg-cyan-400/10 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.08),transparent_35%),linear-gradient(180deg,rgba(255,255,255,0.02),transparent)]" />
      </div>

      <div className="relative z-10 flex h-full flex-col border border-white/8 bg-surface-0/68 shadow-2xl shadow-black/60 backdrop-blur-3xl">
        <TitleBar />
        <div className="flex min-h-0 flex-1">
          <Sidebar />
          {viewMode === 'chat' && <ChatView />}
          {viewMode === 'agent' && <AgentPanel />}
          {viewMode === 'code' && <CodePanel />}
          {viewMode === 'design' && <DesignPanel />}
          {viewMode === 'search' && <SearchPanel />}
          {viewMode === 'memory' && <MemoryPanel />}
          {viewMode === 'settings' && <SettingsPanel />}
        </div>
      </div>
      <CommandPalette />
    </div>
  )
}
