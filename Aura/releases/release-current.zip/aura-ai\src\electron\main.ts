import { app, BrowserWindow, globalShortcut, ipcMain, nativeTheme } from 'electron'
import * as fs from 'fs'
import * as path from 'path'
import { AURA_SYSTEM_PROMPT } from './auraPrompt'
import {
  loadConfig,
  mergeConfig,
  saveConfig,
  listProfiles,
  createProfile,
  updateProfile,
  deleteProfile,
  duplicateProfile,
  setDefaultProfile,
  enableProfile,
  getActiveProfile,
  setActiveProfile,
  exportAllProfiles,
  importAllProfiles,
  backupSettings,
  restoreSettings,
  migrateLegacyToProfile,
  listModels,
  addModel,
  updateModel,
  deleteModel,
  toggleModelPin,
  toggleModelFavorite,
  exportModels,
  importModels,
  getRouting,
  setRouting,
  resolveProfileForTask,
  detectTaskType,
  autoSelectProfile,
  getVoiceSettings,
  setVoiceSettings,
  listDevLogs,
  clearDevLogs,
  getDevStats,
  listPlugins,
  installPlugin,
  enablePlugin,
  disablePlugin,
  removePlugin,
  maskKey,
  secureCopyToClipboard,
} from './aiConfig'
import { PROVIDER_PRESETS, streamCompletion, testConnection, profileToConfig } from './providers'
import { buildMemoryContext, createMemory, deleteMemory, listMemories, maybeCaptureUserMemory, updateMemory } from './memory'

type RendererChatMessage = {
  role: 'user' | 'assistant' | 'system'
  content: string
}

type ChatStartOptions = {
  memoryEnabled?: boolean
  /** Explicit profile picked in the renderer's model picker; wins over keyword routing. */
  profileId?: string
}

type ChatStartRequest = {
  streamId: string
  messages: RendererChatMessage[]
  options?: ChatStartOptions
}

/**
 * Reads the environment block from ~/.claude/settings.json so that
 * secrets like NEON_DATABASE_URL configured there reach the memory backend.
 * Falls back to an empty object; process.env still takes precedence downstream.
 */
function readSettingsEnv(): Record<string, string | undefined> {
  try {
    const settingsPath = path.join(require('os').homedir(), '.claude', 'settings.json')
    const parsed = JSON.parse(fs.readFileSync(settingsPath, 'utf8')) as { env?: Record<string, string> }
    return parsed.env ?? {}
  } catch {
    return {}
  }
}

const settingsEnv = readSettingsEnv()

let mainWindow: BrowserWindow | null = null
const activeStreams = new Map<string, AbortController>()

function getOptionalIconPath() {
  const candidates = [
    path.join(__dirname, '../../public/icon.png'),
    path.join(process.cwd(), 'public/icon.png'),
  ]
  return candidates.find(candidate => fs.existsSync(candidate))
}

function createWindow() {
  const icon = getOptionalIconPath()

  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    transparent: true,
    vibrancy: 'under-window',
    backgroundMaterial: 'mica',
    titleBarStyle: 'hidden',
    trafficLightPosition: { x: 16, y: 16 },
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
    ...(icon ? { icon } : {}),
    show: false,
  })

  if (!app.isPackaged && process.env.AURA_LOAD_BUILT !== '1') {
    void mainWindow.loadURL('http://localhost:5173')
  } else {
    void mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'))
  }

  mainWindow.once('ready-to-show', () => {
    mainWindow?.show()
    mainWindow?.focus()
  })

  mainWindow.on('closed', () => {
    for (const controller of activeStreams.values()) controller.abort()
    activeStreams.clear()
    mainWindow = null
  })
}

function sendToRenderer(channel: string, payload: unknown) {
  mainWindow?.webContents.send(channel, payload)
}

app.whenReady().then(() => {
  migrateLegacyToProfile()
  createWindow()

  globalShortcut.register('CommandOrControl+K', () => {
    mainWindow?.webContents.send('toggle-command-palette')
  })

  nativeTheme.on('updated', () => {
    mainWindow?.webContents.send('theme-updated', nativeTheme.shouldUseDarkColors ? 'dark' : 'light')
  })

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

app.on('will-quit', () => {
  for (const controller of activeStreams.values()) controller.abort()
  activeStreams.clear()
  globalShortcut.unregisterAll()
})

ipcMain.handle('window-minimize', () => mainWindow?.minimize())
ipcMain.handle('window-maximize', () => {
  if (mainWindow?.isMaximized()) {
    mainWindow.unmaximize()
  } else {
    mainWindow?.maximize()
  }
})
ipcMain.handle('window-close', () => mainWindow?.close())
ipcMain.handle('window-is-maximized', () => mainWindow?.isMaximized())
ipcMain.handle('get-theme', () => (nativeTheme.shouldUseDarkColors ? 'dark' : 'light'))

ipcMain.handle('ai:get-status', () => {
  const config = loadConfig()
  const profile = getActiveProfile()
  return {
    hasApiKey: Boolean(profile?.apiKey || config.apiKey),
    baseURL: profile?.baseURL ?? config.baseURL,
    model: profile?.model ?? config.model,
    provider: profile?.provider ?? config.provider,
    mode: config.aiMode,
    activeProfileName: profile?.displayName,
  }
})

ipcMain.handle('ai:get-config', () => loadConfig())
ipcMain.handle('ai:set-config', (_event, partial: Record<string, unknown>) => {
  const current = loadConfig()
  const updated = mergeConfig(current, partial as Partial<typeof current>)
  saveConfig(updated)
  return updated
})
ipcMain.handle('ai:test-connection', async (_event, partial: Record<string, unknown>) => {
  const current = loadConfig()
  const config = mergeConfig(current, partial as Partial<typeof current>)
  return testConnection(config)
})
ipcMain.handle('ai:get-presets', () => PROVIDER_PRESETS)
ipcMain.handle('ai:export-config', () => JSON.stringify(loadConfig(), null, 2))
ipcMain.handle('ai:import-config', (_event, json: string) => {
  let parsed: unknown
  try {
    parsed = JSON.parse(json)
  } catch (error) {
    throw new Error(`Invalid config JSON: ${error instanceof Error ? error.message : 'parse error'}`)
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('Config import must be a JSON object.')
  }
  // Only accept keys that belong to AIConfig; drop anything unexpected.
  const allowed: Array<keyof ReturnType<typeof loadConfig>> = [
    'provider', 'apiKey', 'baseURL', 'model', 'organizationId', 'customHeaders',
    'temperature', 'topP', 'maxTokens', 'streaming', 'reasoningEffort',
    'contextLength', 'aiMode', 'savedModels', 'activeProfileId',
  ]
  const source = parsed as Record<string, unknown>
  const clean: Record<string, unknown> = {}
  for (const key of allowed) {
    if (key in source) clean[key] = source[key]
  }
  const updated = mergeConfig(loadConfig(), clean as never)
  saveConfig(updated)
})

ipcMain.handle('profiles:list', () => listProfiles())
ipcMain.handle('profiles:create', (_event, input) => createProfile(input))
ipcMain.handle('profiles:update', (_event, id: string, updates) => updateProfile(id, updates))
ipcMain.handle('profiles:delete', (_event, id: string) => deleteProfile(id))
ipcMain.handle('profiles:duplicate', (_event, id: string) => duplicateProfile(id))
ipcMain.handle('profiles:set-default', (_event, id: string) => setDefaultProfile(id))
ipcMain.handle('profiles:enable', (_event, id: string, enabled: boolean) => enableProfile(id, enabled))
ipcMain.handle('profiles:get-active', () => getActiveProfile())
ipcMain.handle('profiles:set-active', (_event, id: string) => setActiveProfile(id))
ipcMain.handle('profiles:test-connection', async (_event, profile) => testConnection(profile))
ipcMain.handle('profiles:export-all', () => exportAllProfiles())
ipcMain.handle('profiles:import-all', (_event, json: string) => importAllProfiles(json))
ipcMain.handle('profiles:backup', () => backupSettings())
ipcMain.handle('profiles:restore', (_event, json: string) => restoreSettings(json))

ipcMain.handle('routing:get', () => getRouting())
ipcMain.handle('routing:set', (_event, partial) => setRouting(partial))
ipcMain.handle('routing:resolve', (_event, task: string) => resolveProfileForTask(task as Parameters<typeof resolveProfileForTask>[0]))
ipcMain.handle('routing:detect-task', (_event, content: string) => detectTaskType(content))
ipcMain.handle('routing:auto-select', (_event, content: string) => autoSelectProfile(content))

ipcMain.handle('models:list', () => listModels())
ipcMain.handle('models:add', (_event, input) => addModel(input))
ipcMain.handle('models:update', (_event, id: string, updates) => updateModel(id, updates))
ipcMain.handle('models:delete', (_event, id: string) => deleteModel(id))
ipcMain.handle('models:toggle-pin', (_event, id: string) => toggleModelPin(id))
ipcMain.handle('models:toggle-favorite', (_event, id: string) => toggleModelFavorite(id))
ipcMain.handle('models:export-all', () => exportModels())
ipcMain.handle('models:import-all', (_event, json: string) => importModels(json))

ipcMain.handle('devlogs:list', () => listDevLogs())
ipcMain.handle('devlogs:clear', () => clearDevLogs())
ipcMain.handle('devlogs:stats', () => getDevStats())

ipcMain.handle('voice:get-settings', () => getVoiceSettings())
ipcMain.handle('voice:set-settings', (_event, partial) => setVoiceSettings(partial))
ipcMain.handle('voice:get-voices', () => [])

ipcMain.handle('plugins:list', () => listPlugins())
ipcMain.handle('plugins:enable', (_event, id: string) => enablePlugin(id))
ipcMain.handle('plugins:disable', (_event, id: string) => disablePlugin(id))
ipcMain.handle('plugins:remove', (_event, id: string) => removePlugin(id))
ipcMain.handle('plugins:install', (_event, manifest) => installPlugin(manifest))

ipcMain.handle('security:mask-key', (_event, key: string) => maskKey(key))
ipcMain.handle('security:secure-copy', (_event, text: string) => secureCopyToClipboard(text))

ipcMain.handle('memory:list', async () => listMemories(settingsEnv))
ipcMain.handle('memory:create', async (_event, input) => createMemory(settingsEnv, input))
ipcMain.handle('memory:delete', async (_event, id: string) => deleteMemory(settingsEnv, id))
ipcMain.handle('memory:update', async (_event, id: string, patch: unknown) => {
  // Backward compatible: a bare string is treated as a content-only update.
  const normalized = typeof patch === 'string' ? { content: patch } : (patch as Record<string, unknown>)
  const result = await updateMemory(settingsEnv, id, {
    content: typeof normalized.content === 'string' ? normalized.content : undefined,
    type: normalized.type as never,
    context: typeof normalized.context === 'string' ? normalized.context : undefined,
    relevance: typeof normalized.relevance === 'number' ? normalized.relevance : undefined,
    expiresAt: normalized.expiresAt as number | null | undefined,
  })
  return result.memory
})
ipcMain.handle('memory:export', async () => {
  const { memories } = await listMemories(settingsEnv)
  return JSON.stringify(memories, null, 2)
})
ipcMain.handle('memory:import', async (_event, json: string) => {
  const parsed = JSON.parse(json)
  if (!Array.isArray(parsed)) throw new Error('Invalid memory JSON')
  for (const memory of parsed) {
    if (!memory || typeof memory.content !== 'string') continue
    await createMemory(settingsEnv, {
      type: memory.type,
      content: memory.content,
      context: memory.context,
      relevance: memory.relevance,
      expiresAt: memory.expiresAt ?? null,
    })
  }
})

ipcMain.handle('chat:abort', (_event, streamId: string) => {
  activeStreams.get(streamId)?.abort()
  activeStreams.delete(streamId)
})

ipcMain.handle('chat:start', async (_event, request: ChatStartRequest) => {
  const { streamId, messages, options } = request
  const controller = new AbortController()
  activeStreams.set(streamId, controller)

  const config = loadConfig()
  const lastUserMessage = [...messages].reverse().find(message => message.role === 'user')?.content ?? ''
  const userTurnCount = messages.filter(message => message.role === 'user').length
  const memoryEnabled = options?.memoryEnabled ?? true

  // An explicit model choice from the renderer's picker always wins.
  // Smart routing only picks a profile on the first turn (and only when no
  // explicit choice was sent) so the provider does not silently swap
  // mid-conversation based on the latest message's keywords.
  const allProfiles = listProfiles().filter(p => p.enabled)
  const explicitProfile = options?.profileId
    ? allProfiles.find(p => p.id === options.profileId) ?? null
    : null
  const routedProfile = !explicitProfile && userTurnCount <= 1 ? autoSelectProfile(lastUserMessage) : null

  // Failover chain: preferred profile first, then the remaining enabled
  // profiles. If a provider dies before producing a single token, the next
  // candidate is tried transparently instead of surfacing "fetch failed".
  const preferred = explicitProfile || routedProfile || getActiveProfile() || undefined
  const candidates: NonNullable<typeof preferred>[] = []
  if (preferred) candidates.push(preferred)
  for (const profile of allProfiles) {
    if (!candidates.some(candidate => candidate.id === profile.id)) candidates.push(profile)
  }

  let memoryContext = ''
  let hasMemory = false

  if (memoryEnabled) {
    try {
      await maybeCaptureUserMemory(settingsEnv, lastUserMessage)
      memoryContext = await buildMemoryContext(settingsEnv, lastUserMessage)
      hasMemory = Boolean(memoryContext)
    } catch (error) {
      console.warn('Aura memory unavailable:', error)
    }
  }

  const systemPrompt = memoryContext ? `${AURA_SYSTEM_PROMPT}\n\n${memoryContext}` : AURA_SYSTEM_PROMPT

  queueMicrotask(async () => {
    try {
      // No profiles at all: legacy single-config path, no failover.
      const attempts: Array<ReturnType<typeof getActiveProfile>> = candidates.length > 0 ? candidates : [null]

      for (let index = 0; index < attempts.length; index += 1) {
        const profile = attempts[index] ?? undefined
        const streamConfig = profile ? profileToConfig(profile, config.aiMode) : config
        const isLastAttempt = index === attempts.length - 1
        let tokensSent = false

        const outcome = await new Promise<'done' | 'failed'>(resolve => {
          void streamCompletion(
            streamConfig,
            messages,
            systemPrompt,
            controller.signal,
            {
              onToken: token => {
                tokensSent = true
                sendToRenderer('chat:delta', { streamId, delta: token })
              },
              onThinking: thinking => {
                tokensSent = true
                sendToRenderer('chat:thinking', { streamId, delta: thinking })
              },
              onPipeline: steps => sendToRenderer('chat:pipeline', { streamId, pipeline: steps }),
              onDone: (text, model, usage) => {
                sendToRenderer('chat:done', { streamId, text, model, usage })
                resolve('done')
              },
              onError: error => {
                // Fail over only when this provider produced nothing yet and
                // another candidate remains; otherwise report the error.
                if (!tokensSent && !isLastAttempt && !controller.signal.aborted) {
                  console.warn(`Aura failover: ${profile?.displayName ?? 'config'} failed (${error.message}), trying next provider`)
                  resolve('failed')
                  return
                }
                sendToRenderer('chat:error', { streamId, message: error.message })
                resolve('done')
              },
              onAbort: () => {
                sendToRenderer('chat:aborted', { streamId })
                resolve('done')
              },
            },
            { profile, hasMemory }
          ).catch(error => {
            if (controller.signal.aborted) {
              sendToRenderer('chat:aborted', { streamId })
              resolve('done')
              return
            }
            if (!tokensSent && !isLastAttempt) {
              resolve('failed')
              return
            }
            sendToRenderer('chat:error', { streamId, message: error instanceof Error ? error.message : 'Unknown AI error' })
            resolve('done')
          })
        })

        if (outcome === 'done') break
      }
    } catch (error) {
      if (controller.signal.aborted) {
        sendToRenderer('chat:aborted', { streamId })
        return
      }

      const message = error instanceof Error ? error.message : 'Unknown AI error'
      sendToRenderer('chat:error', { streamId, message })
    } finally {
      activeStreams.delete(streamId)
    }
  })

  return { streamId }
})
